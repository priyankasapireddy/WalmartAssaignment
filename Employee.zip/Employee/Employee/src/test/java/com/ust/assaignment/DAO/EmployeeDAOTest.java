package com.ust.assaignment.DAO;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.ust.assaignment.bo.EmployeeBo;
import com.ust.assaignment.dao.EmployeeMgmtDAO;
import com.ust.assaignment.handler.EmployeeHandlerImpl;
import com.ust.assaignment.model.Employee;
import com.ust.assaignment.repo.EmployeeRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class EmployeeDAOTest {
	
	@InjectMocks
	EmployeeHandlerImpl handler;

	@Mock
	EmployeeRepo repo;

	@Mock
	EmployeeMgmtDAO dao;

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetEmpList() {
		Mockito.when(repo.findAll()).thenReturn(getSampleEmployee());
		List<EmployeeBo> empList = handler.getAllEmployeedetails();
		Assert.assertEquals(2, empList.size());
		Assert.assertEquals("Arathy", empList.get(0).getName());
	}

	/**
	 * function for get employee flux
	 * 
	 * @return Flux<Employee>
	 */
	private Flux<Employee> getSampleEmployee() {
		Employee employee1 = new Employee("wal", "Priyanka", "11-12-2020", "str", 12000, 2, 1, 0);
				
		Employee employee2 = new Employee("wal", "Priyanka", "11-12-2020", "str", 12000, 2, 1, 0);
				
		return Flux.just(employee1, employee2);
	}

	private Flux<Employee> getEmployees() {
		Employee employee1 = new Employee("wal1", "Priyanka", "11-12-2020",null, 12000, 2, 1, 0);
		Employee employee2 = new Employee("wal2", "Supriya", "11-12-19998", "str2", 12000, 2, 1, 0);
				
		return Flux.just(employee1, employee2);
	}

	/**
	 * function for get employee Mono
	 * 
	 * @return Mono<Employee>
	 */
	private Mono<Employee> getMonoEmployee() {
		Employee employee1 = new Employee("wal1", "Priyanka", "11-12-2020", "str1", 12000, 2, 1, 0);
				
		return Mono.just(employee1);
	}
}
