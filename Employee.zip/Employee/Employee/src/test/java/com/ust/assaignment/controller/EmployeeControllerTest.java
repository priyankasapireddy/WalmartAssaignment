package com.ust.assaignment.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ust.assaignment.bo.EmployeeBo;
import com.ust.assaignment.handler.EmployeeHandlerImpl;



public class EmployeeControllerTest {
	
	@InjectMocks
	EmpController controller;

	@Mock
	EmployeeHandlerImpl handler;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();

	}
	
	@Test
	public void testGetEmployeeList() throws Exception {
		List<EmployeeBo> employeeBO = new ArrayList<EmployeeBo>();
		employeeBO.add(new EmployeeBo("wal", "Priyanka", "11-12-2020", "str", 12000, 2, 1, 0));
				
		Mockito.when(handler.getAllEmployeedetails()).thenReturn(employeeBO);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getlist");
		assertNotNull(requestBuilder);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertNotNull(result);
		MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}
	
	@Test
	public void testSearchById() throws Exception {
		EmployeeBo employeeBO = new EmployeeBo("wal", "Priyanka", "11-12-2020", "str", 12000, 2, 1, 0);
				
		Mockito.when(handler.getAllEmployeedetailsByemployeeId(Mockito.any())).thenReturn(employeeBO);
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.get("/searchbyid/U9");
		assertNotNull(requestBuilder);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertNotNull(result);
		MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

}
