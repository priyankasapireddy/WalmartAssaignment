package com.ust.assaignment.Exception;

public class EmployeeException extends RuntimeException {
	
	public EmployeeException(String message) {
		super(message);
	}

	public EmployeeException() {
		super();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -3221190255798269840L;


}
