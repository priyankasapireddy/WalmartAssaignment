package com.ust.assaignment.mapper;

import com.ust.assaignment.model.Employee;

public class EmployeeMapper {
	
	/**
	 * @param employee
	 * @return Employee
	 */
	public Employee mapEmployeeDetail(Employee employee) {
		Employee emp = employee;
		return emp;
	}

}
