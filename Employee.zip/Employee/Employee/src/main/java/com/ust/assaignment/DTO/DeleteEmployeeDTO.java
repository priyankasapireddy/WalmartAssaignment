package com.ust.assaignment.DTO;

public class DeleteEmployeeDTO {
	private String accountName;
	private int band;
	
	public DeleteEmployeeDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DeleteEmployeeDTO(String accountName, int band) {
		super();
		this.accountName = accountName;
		this.band = band;
	}
	
	@Override
	public String toString() {
		return "DeleteEmployeeDTO [accountName=" + accountName + ", band="
				+ band + "]";
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public int getBand() {
		return band;
	}

	public void setBand(int band) {
		this.band = band;
	}

}
