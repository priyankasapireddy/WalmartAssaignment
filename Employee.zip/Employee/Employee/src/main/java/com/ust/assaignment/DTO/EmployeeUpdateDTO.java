package com.ust.assaignment.DTO;

public class EmployeeUpdateDTO {
	
	private String employeeId;
	private String experience;
	private int band;

	public EmployeeUpdateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeUpdateDTO(String employeeId, String experience, int band) {
		super();
		this.employeeId = employeeId;
		this.experience = experience;
		this.band = band;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public int getBand() {
		return band;
	}

	public void setBand(int band) {
		this.band = band;
	}
	
	@Override
	public String toString() {
		return "EmployeeUpdateDTO [employeeId=" + employeeId + ", experience="
				+ experience + ", band=" + band + "]";
	}

}
