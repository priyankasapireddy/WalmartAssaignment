package com.ust.assaignment.repo;

import java.util.List;

import org.springframework.stereotype.Repository;


import reactor.core.publisher.Flux;

import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.ust.assaignment.bo.EmployeeBo;
import com.ust.assaignment.model.Employee;

import reactor.core.publisher.Flux;


@Repository
public interface EmployeeRepo extends ReactiveCosmosRepository<Employee, String> {
	
//	Flux<Employee> getAllEmployeedetails();
//
//	Flux<Employee>  getAllEmployeedetailsByemployeeId(String employeeId);

}
