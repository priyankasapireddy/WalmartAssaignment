package com.ust.assaignment.bo;

public class EmployeeUpdateBo {
	
	private String  employeeId;
	private int experience;
	private int band;

	public EmployeeUpdateBo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeUpdateBo(String employeeId, int experience, int band) {
		super();
		this.employeeId = employeeId;
		this.experience = experience;
		this.band = band;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getBand() {
		return band;
	}

	public void setBand(int band) {
		this.band = band;
	}
	
	@Override
	public String toString() {
		return "EmployeeUpdateBo [employeeId=" + employeeId + ", experience="
				+ experience + ", band=" + band + "]";
	}

}
