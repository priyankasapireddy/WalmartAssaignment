/**
 * className: EmployeeDAOImpl 
 * 
 * Description: EmployeeDAOImpl class implements EmployeeDAO interface
 * 
 * Date: 26/11/2020
 */

package com.ust.assaignment.handler;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;



import com.ust.assaignment.DTO.EmployeeDTO;
import com.ust.assaignment.Exception.EmployeeException;
import com.ust.assaignment.bo.EmployeeBo;
import com.ust.assaignment.dao.EmployeeMgmtDAO;
import com.ust.assaignment.model.Employee;
import com.ust.assaignment.repo.EmployeeRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * EmployeeDAOImpl class that implements EmployeeDAO interface methods
 * 
 * @author sanga
 *
 */
@Service

public class EmployeeHandlerImpl implements IEmployeeHandler {

	
	@Autowired
	EmployeeRepo repo;

	@Autowired
	EmployeeMgmtDAO dao;
	

	List<Employee> empList;
	Set<Employee> empSet;

	/**
	 * EmployeeDAOImpl constructor
	 */
	public EmployeeHandlerImpl() {
//
//		empList = new ArrayList<Employee>();
//		empSet = new HashSet<Employee>();
//
//		Employee fdac1 = new Employee(1234, "Priyanka", "11-12-2020", 123, 12000, 2, 1, 0);
//		Employee fdac2 = new Employee(1235, "Sujatha", "11-12-2020", 124, 15000, 3, 5, 0);
//		Employee fdac3 = new Employee(1236, "Karthika", "11-12-2020", 125, 18000, 5, 3, 0);
//
//		empList.add(fdac1);
//		empList.add(fdac2);
//		empList.add(fdac3);
	}

	/**
	 * getAllEmployeedetails method to fetch all the employees
	 */
	@Override
	public List<EmployeeBo> getAllEmployeedetails() {
		
      Flux<Employee> employeeList = repo.findAll();
		
		List<EmployeeBo> empBOList = new ArrayList<EmployeeBo>();
		
		List<Employee> empList = employeeList.collectList().block();
		
		if (!CollectionUtils.isEmpty(empList)) {
			
			empList.forEach(eachEmp -> {
				
				EmployeeBo employeeBO = new EmployeeBo();
				
				BeanUtils.copyProperties(eachEmp, employeeBO);
				
				empBOList.add(employeeBO);
			});
		}
		return empBOList;
	}

	/**
	 * getAllEmployeedetailsByAccountNo method to fetch AllEmployeedetails
	 * ByAccountName
	 * 
	 */
	@Override
	public EmployeeBo getAllEmployeedetailsByemployeeId(String employeeId) {

		Mono<Employee> emp = repo.findById(employeeId);
		
		if (emp.block() == null) {
			
			throw new EmployeeException( "No such Employee Found");
		} else {
			EmployeeBo employeeBo = new EmployeeBo();
			BeanUtils.copyProperties(emp.block(), employeeBo);
			return employeeBo;
		}
	}

	/**
	 * addNewEmployee method to add a new employee
	 */
	@Override
	public boolean addNewEmployee(Employee employee) {

		boolean isAdded = empSet.add(employee);

		if (isAdded) {
			empList.add(employee);

		}
		return isAdded;
	}

	/**
	 * updateEmployee method is for update Employee details of band and experience
	 */
	@Override
	public void updateEmployee(Employee employee) {
//		// TODO Auto-generated method stub
//		Iterator iterator = empList.iterator();
//
//		while (iterator.hasNext()) {
//
//			Employee emp = (Employee) iterator.next();
//
//			if (emp.getEmployeeId() == employee.getEmployeeId()) {
//
//				emp.setBand(employee.getBand());
//				emp.setExperience(emp.getExperience());
//
//			}
//		}

	}

	/**
	 * deleteAllEmployee is for delete all the employees
	 */
	@Override
	public void deleteAllEmployee() {
		// TODO Auto-generated method stub
		empList.removeAll(getAllEmployeedetails());

	}

	/**
	 * deleteEmployee method is for delete Employee based on accountName
	 * 
	 */
	@Override
	public void deleteEmployee(String employeeId) {
//		// TODO Auto-generated method stub
//		Employee emp = null;
//
//		for (int i = 0; i < empList.size(); i++) {
//
//			emp = (Employee) empList.get(i);
//
//			if (emp.getEmployeeId() == employeeId) {
//
//				empList.remove(i);
//
//			}
//
//		}
	}

	/**
	 * updateEmployeeBonous method is for update Employee bonous of particular
	 * employee
	 */
	@Override
	public void updateEmployeeBonous(Employee employee) {
//		Iterator iterator = empList.iterator();
//
//		while (iterator.hasNext()) {
//
//			Employee emp = (Employee) iterator.next();
//
//			if (emp.getAccountName() == employee.getAccountName()) {
//
//				emp.setBonous(employee.getBonous());
//
//			}
//		}

	}

	@Override
	public List<Employee> addFreshers(List<Employee> emp) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * addFreshers method to add freshers and add 2 employees at a time
	 */
	
		
		
	

	
	
}
