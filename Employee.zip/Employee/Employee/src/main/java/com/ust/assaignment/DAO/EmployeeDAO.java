/**
 * Interface Name:   EmployeeDAO
 * 
 * Description:  EmployeeDAO interface contains methods according to the requirements 
 * 
 * Date: 26/11/2020
 */

package com.ust.assaignment.DAO;

import java.util.List;

import com.ust.assaignment.model.Employee;

/**
 * EmployeeDAO interface contains methods getAllEmployeedetails,
 * getAllEmployeedetailsByAccountNo, addNewEmployee, addFreshers
 * ,updateEmployee,updateEmployeeBonous deleteEmployee, deleteAllEmployee
 *
 *
 */

public interface EmployeeDAO {

	public List<Employee> getAllEmployeedetails();

	public Employee getAllEmployeedetailsByemployeeId(int employeeId);

	public boolean addNewEmployee(Employee employee);

	public List<Employee> addFreshers(List<Employee> emp);

	public void updateEmployee(Employee employee);

	public void updateEmployeeBonous(Employee employee);

	public void deleteEmployee(int employeeId);

	public void deleteAllEmployee();
}

/**
 * 1* Fetch all the employees
 * 
 * 2. Fetch all the employees of a given account.
 * 
 * 3. Add a new employee
 * 
 * 4. Add a batch of freshers (more than 2 employees should be added at a time)
 * 
 * 5. Update the experience and band of a given employee
 * 
 * 6. Add given bonus to a particular employee.
 * 
 * 7. Remove an employee
 * 
 * 8. Remove all the employees of a given account who belongs to a given band.
 */
