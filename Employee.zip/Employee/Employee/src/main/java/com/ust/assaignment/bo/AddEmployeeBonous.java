package com.ust.assaignment.bo;

public class AddEmployeeBonous {
	
	private String employeeId;
	private int bonus;
	
	public AddEmployeeBonous() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

	public AddEmployeeBonous(String employeeId, int bonus) {
		super();
		this.employeeId = employeeId;
		this.bonus = bonus;
	}
	
	@Override
	public String toString() {
		return "AddEmployeeBonous [employeeId=" + employeeId + ", bonus=" + bonus
				+ "]";
	}


}
