/**
 * Class:  EmployeeService  
 * 
 * Description: EmployeeService is a service class by autowiring EmployeeDAOImpl 
 * 
 * Date:26/11/2020
 */
package com.ust.assaignment.service;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ust.assaignment.DAO.EmployeeDAO;
import com.ust.assaignment.DAO.EmployeeDAOImpl;
import com.ust.assaignment.model.Employee;

/**
 * EmployeeService service class to present the outputsin order
 *
 */
@Service
public class EmployeeService {

	// autowiring EmployeeDAOImpl by creating object by super type EmployeeDAO

	@Autowired
	private EmployeeDAO employeeDAO;

	/**
	 * EmployeeService class constructor
	 */
	public EmployeeService() {

		employeeDAO = new EmployeeDAOImpl();

	}

	/**
	 * getAllEmployeedetails method that access the getAllEmployeedetails method in
	 * EmployeeDAOImpl
	 * 
	 * @return EmployeeList
	 */
	public List<Employee> getAllEmployeedetails() {

		List currentAccountList = employeeDAO.getAllEmployeedetails();

		Iterator<Employee> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			Employee pe = iterator.next();
		}

		return currentAccountList;

	}

	/**
	 * getAllEmployeedetailsByAccountNo method that access the
	 * getAllEmployeedetailsByAccountNo method in EmployeeDAOImpl
	 * 
	 * @param accountNo
	 * @return Employee
	 */
	public Employee getAllEmployeedetailsByemployeeId(int employeeId) {

		Employee pe = employeeDAO.getAllEmployeedetailsByemployeeId(employeeId);
		return pe;

	}

	/**
	 * deleteEmployee method that access the deleteEmployee method in
	 * EmployeeDAOImpl to delete employee by accountName
	 * 
	 * @param accountName
	 */
	public void deleteEmployee(int employeeId) {

		employeeDAO.deleteEmployee(employeeId);

	}

	/**
	 * deleteAllEmployee method that access the deleteAllEmployee method in
	 * EmployeeDAOImpl to delete employee by accountName
	 */
	public void deleteAllEmployee() {

		employeeDAO.deleteAllEmployee();

	}

	/**
	 * addNewEmployee method that access the addNewEmployee method in
	 * EmployeeDAOImpl to add employee
	 * 
	 * @param employee
	 */
	public void addNewEmployee(Employee employee) {

		boolean isAdded = employeeDAO.addNewEmployee(employee);

		if (!isAdded) {

			System.out.println("The Employee already exist");
		} else {
			System.out.println("The Employee successfully added");

		}

	}

	/**
	 * updateEmployee method that access the updateEmployee method in
	 * EmployeeDAOImpl to update employee
	 * 
	 * @param Employee
	 */
	public void updateEmployee(Employee emp) {

		employeeDAO.updateEmployee(emp);
	}

	/**
	 * updateEmployeeBonous method that access the updateEmployeeBonous method in
	 * EmployeeDAOImpl to update employee bonus
	 * 
	 * @param Employee
	 */
	public void updateEmployeeBonous(Employee emp) {

		employeeDAO.updateEmployeeBonous(emp);
	}
	
	/**
	 * addFreshers method that access the addFreshers method in
	 * EmployeeDAOImpl to add 2 freshers at a time 
	 * 
	 * @param Employee
	 */
	public List<Employee> addFreshers(List<Employee> emp1 ) {
		
		List<Employee>  emplist =  employeeDAO.addFreshers(emp1) ;
		
		return  emplist ;

		

	}

}
