/**
 * Class:  EmployeeApplication 
 * 
 * Description: EmployeeApplication contains main method to run the application
 * 
 * Date: 26/11/2020
 */
package com.ust.assaignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * EmployeeApplication contain main method and main SpringBootApplication
 */
@SpringBootApplication
public class EmployeeApplication {
	/**
	 * Main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(EmployeeApplication.class, args);
	}

}
