/**
 * InterfaceName: ReportServiceConstant
 * 
 * Description: ReportServiceConstant interface for storing all the constants
 * 
 * Date:26/11/2020
 * 
 */

package com.ust.assaignment.ConstantFile;

public interface ReportServiceConstant {
	
	public static final String URL_MAPPING_GET_ALLEMPLOYEES = " /empall";
	
	public static final String URL_MAPPING_GET_EMPLOYEEBYID = "/empall/{employeeId}";
	
	public static final String URL_MAPPING_POST_ADDEMPLOYEE = "/addEmp";
	
	public static final String URL_MAPPING_POST_ADDFRESHERS = "/addFreshers";
	
	public static final String URL_MAPPING_PUT_UPDATEEMPLOYEE = "/upEmp/{employeeId}";
	
	public static final String URL_MAPPING_PUT_UPDATEBONOUS = "/updateBonous/{employeeId}";
	
	public static final String URL_MAPPING_DELETE_DELETEALLEMPLOYEE = "/deltEmpAll";
	
	public static final String URL_MAPPING_DELETE_DELETEEMPLOYEE = "/deltEmp/{employeeId}";
	

	
	

}
