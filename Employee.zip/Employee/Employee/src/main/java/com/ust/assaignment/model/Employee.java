/**
 * ClassName: Employee
 * 
 * Description: Employee class is a base class which contains setter and getter methods to initialize the defined variables
 * 
 * Date: 26/11/2020
 */

package com.ust.assaignment.model;

import java.util.Date;

/**
 * Employee class contains private variables and getter and setter methods
 * 
 *
 */
public class Employee {

	private int employeeId;
	private String name;
	private String joiningdate;
	private int accountName;
	private int salary;
	private int experience;
	private int band;
	private int bonous;

	

	/**
	 * Employee class parameterized constructor as following parameters
	 * 
	 * @param employeeId
	 * @param name
	 * @param joiningdate
	 * @param accountName
	 * @param salary
	 * @param experience
	 * @param band
	 * @param  bonous
	 * 
	 */
	public Employee(int employeeId, String name, String joiningdate, int accountName, int salary, int experience,
			int band,int bonous) {
		this.employeeId = employeeId;
		this.name = name;
		this.joiningdate = joiningdate;
		this.accountName = accountName;
		this.salary = salary;
		this.experience = experience;
		this.band = band;
		this.bonous = bonous;

		// TODO Auto-generated constructor stub
	}

	/**
	 * employeeId getter and setter method
	 * 
	 * @return employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * name getter and setter methods
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", joiningdate=" + joiningdate
				+ ", accountName=" + accountName + ", salary=" + salary + ", experience=" + experience + ", band="
				+ band + ", bonous=" + bonous + "]";
	}

	/**
	 * joiningDate getter and setter method
	 * 
	 * @return joiningdate
	 */
	public String getJoiningdate() {
		return joiningdate;
	}

	public void setJoiningdate(String joiningdate) {
		this.joiningdate = joiningdate;
	}

	/**
	 * accountName getter and setter method
	 * 
	 * @return accountName
	 */
	public int getAccountName() {
		return accountName;
	}

	public void setAccountName(int accountName) {
		this.accountName = accountName;
	}

	/**
	 * salary getter and setter method
	 * 
	 * @return salary
	 */
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	/***
	 * experience getter and setter method
	 * 
	 * @return experience
	 */
	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	/**
	 * band getter and setter methods
	 * 
	 * @return band
	 */
	public int getBand() {
		return band;
	}

	public void setBand(int band) {
		this.band = band;
	}
	/**
	 * bonus getter and setter methods
	 * @return
	 */
	public int getBonous() {
		return bonous;
	}

	public void setBonous(int bonous) {
		this.bonous = bonous;
	}

	/**
	 * giveBand method is to determine the band grate
	 */
	public void giveBand(int band) {

		if (band == 1) {

			this.band = 'A';
			System.out.println("band");
		} else if (band <= 4) {

			this.band = 'B';
			System.out.println("band");

		} else {

			this.band = 'C';
			System.out.println("band");

		}

	}

}
