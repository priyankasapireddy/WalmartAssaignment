/**
 * Class:  EmpController
 * 
 * Description: EmpController a controller class   for mapping the data 
 * 
 * Date:26/11/2020
 * 
 */
package com.ust.assaignment.controller;

import java.util.List;
import static  com.ust.assaignment.ConstantFile.ReportServiceConstant.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.ust.assaignment.model.Employee;
import com.ust.assaignment.service.EmployeeService;

/**
 * EmpController controller class by autowiring EmployeeService
 * 
 */

@RestController
public class EmpController {

	@Autowired
	private EmployeeService service;

	/**
	 * by getmapping annoattion we can access getAllEmployeedetails method inetnally
	 * calls getAllEmployeedetails method in service class
	 * 
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_MAPPING_GET_ALLEMPLOYEES)
	public List<Employee> getAllEmployeedetails() {

		System.out.println("Inside controller getAllEmployeedetails ");

		List<Employee> employeeList = service.getAllEmployeedetails();

		return employeeList;

	}
	/**
	 * by getmapping annoattion we can access getAllEmployeedetails method inetnally
	 * calls getAllEmployeedetails method in service class
	 * 
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_MAPPING_GET_EMPLOYEEBYID)
	public Employee getAllEmployeedetailsByemployeeId( @PathVariable int employeeId) {

	 Employee pe = service.getAllEmployeedetailsByemployeeId(employeeId);
		 
	 return pe ;
		

	}

	/**
	 * postMapping(/addEmp) we can access addNewEmployee method in service class to
	 * add a new emloyee
	 * 
	 * @param Employee
	 * @return Employee
	 */
	@PostMapping(value= URL_MAPPING_POST_ADDEMPLOYEE )
	public Employee addEmployee(@RequestBody Employee employee) {

		 service.addNewEmployee(employee);

		return employee;
	}
	/**
	 * postMapping(/addFreshers) we can access addFreshers method in service class to
	 * add 2 new emloyees
	 * 
	 * @param Employee
	 * @return Employee
	 */
	@PostMapping(value = URL_MAPPING_POST_ADDFRESHERS )
	public   List<Employee>  addFreshers(@RequestBody  List<Employee>  employee) {

		List<Employee> empList = service.addFreshers(employee);
		
		return empList;

		
	}
	
	/**
	 * @RequestMapping(value="/addEmp/{accountName}" internally calls updateEmployee
	 * method in service class
	 * 
	 * @param accountName
	 * @param Employee
	 * @return Employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEEMPLOYEE, method = RequestMethod.PUT)
	public Employee updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {

		service.updateEmployee(employee);

		return employee;

	}
	/**
	 * @RequestMapping(value = "/updateBonous/{accountName}  internally calls updateEmployeeBonous method in service class 
	 * @param accountName
	 * @param Employee
	 * @return Employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEBONOUS , method = RequestMethod.PUT)
	public Employee updateEmployeeBonous(@PathVariable int employeeId, @RequestBody Employee employee) {

		service.updateEmployeeBonous(employee);

		return employee;

	}
	/**
	 * @RequestMapping(value="/deltEmp/{accountName}") internally calls deleteEmployeemethod in service class and delete employee
	 * @param accountName
	 */
	@RequestMapping(value=URL_MAPPING_DELETE_DELETEALLEMPLOYEE,method=RequestMethod.DELETE) 
	public void deleteEmp(@PathVariable int employeeId) {
	
		
     service.deleteEmployee(employeeId);
		
	}
	/**
	 * @RequestMapping(value="/deltEmpAll") internally calls deleteAllEmployee method and delete all employees 
	 */
	@RequestMapping(value= URL_MAPPING_DELETE_DELETEEMPLOYEE ,method=RequestMethod.DELETE) 
	public void deleteAllemp() {
	
		
     service.deleteAllEmployee();
		
	}

}
