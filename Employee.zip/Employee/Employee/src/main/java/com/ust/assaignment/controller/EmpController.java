/**
 * Class:  EmpController
 * 
 * Description: EmpController a controller class   for mapping the data 
 * 
 * Date:26/11/2020
 * 
 */
package com.ust.assaignment.controller;



import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import javax.ws.rs.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import static com.ust.assaignment.ConstantFile.ReportServiceConstant.GET_EMPLOYEE_LIST_VALUE;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_DELETE_DELETEALLEMPLOYEE;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_DELETE_DELETEEMPLOYEE;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_GET_ALLEMPLOYEES;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_GET_EMPLOYEEBYID;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_POST_ADDEMPLOYEE;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_POST_ADDFRESHERS;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_PUT_UPDATEBONOUS;
import static com.ust.assaignment.ConstantFile.ReportServiceConstant.URL_MAPPING_PUT_UPDATEEMPLOYEE;

import static com.ust.assaignment.ConstantFile.ReportServiceConstant.GET_EMPLOYEE_BY_ID;

import com.ust.assaignment.ConstantFile.ReportServiceConstant;
import com.ust.assaignment.DTO.EmployeeDTO;
import com.ust.assaignment.Exception.EmployeeException;

import io.swagger.annotations.ApiOperation;
import com.ust.assaignment.ConstantFile.*;
import com.ust.assaignment.annotation.SwaggerToken;
import com.ust.assaignment.bo.EmployeeBo;
import com.ust.assaignment.handler.EmployeeHandlerImpl;
import com.ust.assaignment.model.Employee;


import io.swagger.annotations.ApiOperation;

/**
 * EmpController controller class by autowiring EmployeeService
 * 
 */

@RestController

public class EmpController {

	@Autowired
	EmployeeHandlerImpl employeeDAOImpl;
//	private EmployeeService service;

	/**
	 * by getmapping annoattion we can access getAllEmployeedetails method inetnally
	 * calls getAllEmployeedetails method in service class
	 * 
	 * @return List<Employee>
	 */
	
	@GetMapping(value = URL_MAPPING_GET_ALLEMPLOYEES)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEE_LIST_VALUE, notes = ReportServiceConstant.NOTES_FOR_SWAGGER,
	httpMethod = javax.ws.rs.HttpMethod.GET)
	
	public ResponseEntity<?> getAllEmployeedetails() {
		
	   ResponseEntity<?> response = null;
	   
		List<EmployeeBo> employeeListBO = employeeDAOImpl.getAllEmployeedetails();
		
		if (!CollectionUtils.isEmpty(employeeListBO)) {
			List<EmployeeDTO> employeeListDTO = new ArrayList<EmployeeDTO>();
			employeeListBO.forEach(eachEmp -> {
				EmployeeDTO empDTO = new EmployeeDTO();
				BeanUtils.copyProperties(eachEmp, empDTO);
				employeeListDTO.add(empDTO);
			});
			response = ResponseEntity.ok(employeeListDTO);
		}
		return response;
	}

		

	
	/**
	 * by getmapping annoattion we can access getAllEmployeedetails method inetnally
	 * calls getAllEmployeedetails method in service class
	 * 
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_MAPPING_GET_EMPLOYEEBYID)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEE_BY_ID, notes = ReportServiceConstant.NOTES_FOR_SWAGGER,
	httpMethod = javax.ws.rs.HttpMethod.GET)
	
	public ResponseEntity<?> getAllEmployeedetailsByemployeeId(@PathVariable(value = "employeeId") String employeeId)
				throws EmployeeException {
		
			ResponseEntity<EmployeeDTO> response = null;
			
			EmployeeBo employee = employeeDAOImpl.getAllEmployeedetailsByemployeeId(employeeId);
			
			if (employee != null) {
				EmployeeDTO empDTO = new EmployeeDTO();
				BeanUtils.copyProperties(employee, empDTO);
				response = ResponseEntity.ok(empDTO);
			}
			return response;

		
	   
		

	}

	/**
	 * postMapping(/addEmp) we can access addNewEmployee method in service class to
	 * add a new emloyee
	 * 
	 * @param Employee
	 * @return Employee
	 */
	@PostMapping(value= URL_MAPPING_POST_ADDEMPLOYEE )
	public Employee addEmployee(@RequestBody Employee employee) {

		employeeDAOImpl.addNewEmployee(employee);

		return employee;
	}
	/**
	 * postMapping(/addFreshers) we can access addFreshers method in service class to
	 * add 2 new emloyees
	 * 
	 * @param Employee
	 * @return Employee
	 */
	@PostMapping(value = URL_MAPPING_POST_ADDFRESHERS )
	public   List<Employee>  addFreshers(@RequestBody  List<Employee>  employee) {

		List<Employee> empList = employeeDAOImpl.addFreshers(employee);
		
		return empList;

		
	}
	
	/**
	 * @RequestMapping(value="/addEmp/{accountName}" internally calls updateEmployee
	 * method in service class
	 * 
	 * @param accountName
	 * @param Employee
	 * @return Employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEEMPLOYEE, method = RequestMethod.PUT)
	public Employee updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {

		employeeDAOImpl.updateEmployee(employee);

		return employee;

	}
	/**
	 * @RequestMapping(value = "/updateBonous/{accountName}  internally calls updateEmployeeBonous method in service class 
	 * @param accountName
	 * @param Employee
	 * @return Employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEBONOUS , method = RequestMethod.PUT)
	public Employee updateEmployeeBonous(@PathVariable int employeeId, @RequestBody Employee employee) {

		employeeDAOImpl.updateEmployeeBonous(employee);

		return employee;

	}
	/**
	 * @RequestMapping(value="/deltEmp/{accountName}") internally calls deleteEmployeemethod in service class and delete employee
	 * @param accountName
	 */
	@RequestMapping(value=URL_MAPPING_DELETE_DELETEALLEMPLOYEE,method=RequestMethod.DELETE) 
	public void deleteEmp(@PathVariable String employeeId) {
	
		
		employeeDAOImpl.deleteEmployee(employeeId);
		
	}
	/**
	 * @RequestMapping(value="/deltEmpAll") internally calls deleteAllEmployee method and delete all employees 
	 */
	@RequestMapping(value= URL_MAPPING_DELETE_DELETEEMPLOYEE ,method=RequestMethod.DELETE) 
	public void deleteAllemp() {
	
		
		employeeDAOImpl.deleteAllEmployee();
		
	}

}
