package com.ust.assaignment.ConstantFile;

public class SQLQueries {
	
	public static String FETCH_ALL_WITH_LIMIT = "select * from employee where employee.accountName = @account offset @offset limit @limit";
	public static String FETCH_EMPLOYEE_WITH_ID = "select * from employee where employee.employeeId = @employeeId";

}
