/**Class: CountriesExecrcise
 * 
 * date:30/11/2020
 * 
 * Description: Create a List with Name of people . Each person has a first name and last name.
   Example: ['Bruno Fernandes', 'Timo Werner', 'Calvert Lewin']

Sort the list in descending order of Last Name.
Display the list interchanging the first name and last name.
Add a new field to Person � age Group with values- minor and major. Classify the list based on age group.
 */

package com.ust.walmart.execrcise2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.swing.text.html.HTMLDocument.Iterator;

import com.ust.walmart.execrcise3.Person;

/**
 * Class which contains list of countries contains methods to remove duplicates
 * , find a country, sort the countries list, classifing the list based on
 * length of countries, adding the countries on specified position
 * 
 * @author sanga
 *
 */
public class CountriesExecrcise {

	public static void main(String[] args) {

		// created a list<String> of countries
		List<String> countries = new ArrayList<String>();
		countries.add("India");
		countries.add("Australia");
		countries.add("USA");
		countries.add("SouthAfrica");
		countries.add("Germany");
		countries.add("USA");

		countries.add("Australia");

		removeDuplicate(countries).forEach(System.out::println);
		

	     System.out.print(searchElement(countries, "USA"));

//		Map<Integer, String> newCountries = new HashMap<Integer, String>();
//		
//		newCountries.put(1, "Italy");
//		newCountries.put(6, "Brazil");
//		newCountries.put(3, "China");
//		System.out.println(addElements(countries, newCountries));
//		
//		System.out.print(countries);
		
	    vowelCountInString(countries);
	    
		classifyList(countries);
		
		System.out.println(sortCountries(countries));

	}

	/**
	 * method to remove all the duplicate values in the list
	 * 
	 * @param countries
	 * @return List of Countries
	 */
	public static List<String> removeDuplicate(List<String> countries) {
		List<String> newCountriesList = new ArrayList<String>();

		newCountriesList.addAll(countries.stream().distinct().collect(Collectors.toList()));
		return newCountriesList;
	}

	/**
	 * searchElement method for search a given country
	 * 
	 * @param countries
	 * @param countryName
	 * @return
	 */
	public static List<String> searchElement(List<String> countries, String countryName) {

		List<String> countrysearched = countries.stream().filter(country -> country.equalsIgnoreCase(countryName))
				.collect(Collectors.toList());

		return countrysearched;
	}

	/**
	 * method to addElements to the list
	 * 
	 * @param countries
	 * @param newCountries
	 * @return List of Countries
	 */
	public static List<String> addElements(List<String> countries, Map<Integer, String> newCountries) {
		// List<String> newCountriesList = new ArrayList<String>();

		newCountries.forEach((k, v) -> {
			countries.add(k, v);
		});
		return countries;

	}

	/**
	 * method to count the vowels
	 * 
	 * @param countries
	 * @param numberOfVowels
	 */
	public static void vowelCountInString(List<String> countries) {

		long numberOfVowels = 0;
		for (String country : countries) {

			numberOfVowels = country.toLowerCase().chars().mapToObj(i -> (char) i)
					.filter(vowels -> "aeiou".contains(String.valueOf(vowels))).count();

			System.out.println("number of vowels in each string in list are :  " + numberOfVowels);

		}

	}

	/**
	 * method to classifyList based on the length of countries
	 * 
	 * @param countries
	 * @return classifiedCountries
	 */
	public static void classifyList(List<String> countries) {

		List<String> countries1 = countries.stream().filter(country -> country.length() > 6)
				.collect(Collectors.toList());

		List<String> countries2 = countries.stream().filter(country -> country.length() <= 6)
				.collect(Collectors.toList());

		HashMap<String, List<String>> map = new HashMap<String, List<String>>(); // Creating HashMap

		map.put("longestCountry", countries1);
		map.put("smallCountry", countries2);

		System.out.println("major and minor Lists are :");
		System.out.println(map);

	}

	/**
	 * method to sortCountries
	 * 
	 * @param countries
	 * @return List of Countries
	 */
	public static List<String> sortCountries(List<String> countries) {

		countries.sort((s1, s2) -> s1.length() - s2.length());

		return countries;
	}
}
