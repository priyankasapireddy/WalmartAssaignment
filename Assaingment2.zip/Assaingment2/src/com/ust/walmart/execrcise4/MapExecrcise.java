/**
 * Class: MapExecrcise
 * 
 * Date : 30/11/2020
 * 
 * description: MapExecrcise class has map to store key value pairs from user and find the maximum key value pair .
 */



package com.ust.walmart.execrcise4;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;
/**
 * MapExecrcise class has map to store key value pairs from user and find the maximum key value pair .
 * @author sanga
 *
 */
public class MapExecrcise {

	public static void main(String[] args)  throws InterruptedException {
	
		Scanner scanner = new Scanner(System.in); 
		 
		HashMap<String,Integer> map=new HashMap<String,Integer>();//Creating HashMap
		
		 System.out.println("enter  the  key value pairs  : " );
		 boolean loopAgain = true;
			Scanner scan = new Scanner(System.in);

			// loop while user not entering no
			do {
				// ask for user input  value
				System.out.print("Enter key :");
				String key = scan.nextLine();  
				
				// ask for user input for key
				System.out.print("Enter value  :");
				Integer value = Integer.parseInt(scan.nextLine());

				

				// add the key value pair from user input to the Hashmap

				Integer mapkeyValues = map.put(key, value);

				if (mapkeyValues!=null) {
					
					System.out.println("key :" + key + " is "
							+ mapkeyValues + " value " + value);
				}

				// ask user to check if another entry is required
				System.out.print("Enter another map value (y/n)?");
				String answer = scan.nextLine();

				// condition to satisfy in order to loop again
				if (answer.equals("y") || answer.equals("Y")) {
					continue;
				} else {
					break;
				}

			} while (loopAgain);
			scan.close();

			System.out.println("\n**********************************");
			System.out.println("The following students are in database");
			System.out.println("   key   "+ "      value");		
			for(String id:map.keySet()){
				
				System.out.println("   "+id+"     "+map.get(id));
			}
			System.out.println("\n**********************************");
			
		//to get maximum value in map 
			
			Integer max= map.entrySet().stream().max(Map.Entry.comparingByValue()).get().getValue();
			
			Integer min= map.entrySet().stream().min(Map.Entry.comparingByValue()).get().getValue();
					
			
			
			
			System.out.println(  "Entry with highest value: "  + max); 
			System.out.println(  "Entry with highest value: "  + min); 
		}
		 
	
}
	 
	

		

	


