/**
 * Class:Person
 * 
 * Date:30/11/2020
 * 
 * description: class Person which contains List with Name of people . Each person has a first name and last name
 */

package com.ust.walmart.execrcise3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

public class Person {

	// declared variable fname ,lname,age
	private String fName;
	private String lname;
	private int age;

	public Person(String fName, String lname, int age) {
		this.fName = fName;
		this.lname = lname;
		this.age = age;
	}

	// getter and setter method to fname
	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	// getter and setter method to lname
	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	// getter and setter method to age
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "Person [fName=" + fName + ", lname=" + lname + ", age=" + age + "]";
	}

	public static void main(String[] args) {

		Person e1 = new Person("aTestName", "xLastName", 34);
		Person e2 = new Person("nTestName", "pLastName", 30);
		Person e3 = new Person("kTestName", "sLastName", 31);
		Person e4 = new Person("dTestName", "zLastName", 18);

		List<Person> person = new ArrayList<Person>();

		person.add(e1);
		person.add(e2);
		person.add(e3);
		person.add(e4);

		System.out.println("list of person: ");

		person.stream().forEach(System.out::println);

		

		sortListByUsingLastName(person);

		System.out.println("******************************");

		interchangeFirstAndlastname(person);

		System.out.println("******************************");

		classifyListBasedOnAge(person);

	}
/**
 * classifyListBasedOnAge method to classify the list into two lists based on age group
 * @param person
 */
	private static void classifyListBasedOnAge(List<Person> person) {

		List<Person> person1 = person.stream().filter(age -> age.getAge() < 20).collect(Collectors.toList());

		List<Person> person2 = person.stream().filter(age -> age.getAge() >= 20).collect(Collectors.toList());

		HashMap<String, List<Person>> map = new HashMap<String, List<Person>>();// Creating HashMap

		map.put("minor", person1);
		map.put("major", person2);

		System.out.println("major and minor Lists are :");
		System.out.println(map);

	}
/**
 * interchangeFirstAndlastname method to interchange first and last name and display list
 * @param person
 */
	private static void interchangeFirstAndlastname(List<Person> person) {

//	person.forEach(a->{a.setfName(a.getLname());a.setLname(a.getfName());});
//	System.out.println(person);

		List<Person> newList = person.stream().map(f -> new Person(f.getLname(), f.getfName(), f.getAge()))
				.collect(Collectors.toList());

		System.out.println("list after interchanging first and lastname");
		newList.stream().forEach(System.out::println);

	}

	// personList.stream().forEach(System.out::println);

	/**
	 * sortListByUsingLastName method to sort the list byLastname in descending
	 * order
	 * 
	 * @param person
	 */
	private static void sortListByUsingLastName(List<Person> person) {

		Function<Person, String> byLastName = Person::getLname;

		// Comparator for comparing Employees by first name then last name

		Comparator<Person> bylastnameComparator = Comparator.comparing(byLastName);

		System.out.println("sorted list by using lastname : ");
		person.stream().sorted(bylastnameComparator.reversed()).forEach(System.out::println);

	}

}
