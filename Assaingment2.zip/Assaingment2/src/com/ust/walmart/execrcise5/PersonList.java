/**
 * Class:PersonList
 * 
 * Date:30/11/2020
 * 
 * Description: Class PersonList has a ArrayList  takes the input from the user to append it to all the values in the list 
 */

package com.ust.walmart.execrcise5;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
/**
 * Class PersonList has a ArrayList  takes the input from the user to append it to all the values in the list 
 * @author sanga
 *
 */
public class PersonList {

	public static void main(String[] args) {
		
		 Scanner scanner = new Scanner(System.in); 
		 
		 ArrayList<String> names = new ArrayList<String>(); 
		 
		 names.add("Ravi");
		 names.add("Avash");
		 names.add("Raghu");
		 names.add("Abraham");
		 
		 System.out.println("enter  the names you want to add  : " );
		 
		    String string = scanner.nextLine();
		    
		   String joinednames =  names.stream().map(Object::toString).collect( Collectors.joining(string+",  "));
		    
		    System.out.println(joinednames);
                             
                        
		 
		 
		    
	
		 
		 
		
	    } 

	}


