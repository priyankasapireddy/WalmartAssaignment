/**
 * Class: Execrcise1
 * 
 * Date:30/11/2020
 * 
 * Description: Execrcise1 class contains a method to find longest words in a paragraph and a method to display reverse order of paragraph
 */

package com.ust.walmart.execrcise1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
/**
 *  Execrcise1 class contains a method to find longest words in a paragraph and a method to display reverse order of paragraph
 * @author sanga
 */
public class Execrcise1 {

	public static void main(String[] args) throws Exception{
		
      File file = file = new File("D:\\eclipse-workspaceformvn\\Assaingment2\\src\\com\\ust\\walmart\\execrcise1\\Paragraph");
      
       List<String> paragraph = textToList(file);
       
        displayParagraph(paragraph);
        
        System.out.print(longestWordsInParagraph(paragraph));
      
     
		 
	}
	/**
	 * textToList method to converts the paragraph to list of strings 
	 * @param file
	 * @return
	 * @throws Exception
	 */
	public static List textToList(File file)throws Exception{
		
		List<String> paragraph = new ArrayList<String>();
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		 String st; 
		 
		 String str = "";
		  while ((st = br.readLine()) != null) {
			  
			  str = str + st;
			 
		  }
		  
		  Collections.addAll(paragraph, str.split("\\W+"));
		
		return paragraph;
	}

	/**
	 * displayParagraph method to display the paragraph in reverse order
	 * @param paragraph
	 */
	public static void displayParagraph(List<String> paragraph){
		
		paragraph.stream().collect(Collectors.toCollection(LinkedList::new)).descendingIterator().forEachRemaining(System.out::println);
	}
	
	/**
	 * longestWordsInParagraph method to display words with longest length
	 * @param paragraph
	 * @return List of longestWords
	 */
	public static Optional<String> longestWordsInParagraph(List<String> paragraph){
		
		
		
		 Optional<String> longest = paragraph.stream()
		            .reduce((s1, s2) -> {
		                if (s1.length() > s2.length())
		                	
		                    return s1;
		                else
		                    return s2;
		            });
         
		
				 
				  
				  return longest;
	}
}

