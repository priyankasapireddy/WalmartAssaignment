/**
 * Class: FibonacciSeries
 * Date:30/11/2020
 * Description:Class FibonacciSeries displays fibonacci series from 1-50  and find the sum of collection using reduce
 */

package com.ust.walmart.execrcise6;

import static java.util.stream.Collectors.toList;

import java.util.List;
import java.util.stream.Stream;
/**
 * Class FibonacciSeries displays FibonacciSeries from 1-50  and find the sum of collection using reduce
 * @author sanga
 *
 */
public class FibonacciSeries {
	/**
	 * Main method
	 * @param args
	 */
	 public static void main(String[] args) {

	        List<Integer> fibonacci = getFibonacci(10);
	        
	        fibonacci.forEach(x -> System.out.println(x));
	     
	        getFibonacciSum(10);
	      

	    }
/**
 * getFibonacci to display the series from 1-50 
 * @param series
 * @return List of fibanocci
 */
	public static List<Integer> getFibonacci(int series) {
        return Stream.iterate(new int[]{0, 1}, t -> new int[]{t[1], t[0] + t[1]})
                .limit(series)
                .map(n -> n[0])
                .collect(toList());
    }
	
	/**
	 * getFibonacciSum  method to find the sum of  fibenocci series from 1 to 50
	 */
	
	public static  int  getFibonacciSum(int series) {
	  int sum = Stream.iterate(new int[]{0, 1}, t -> new int[]{t[1], t[0] + t[1]})
		        .limit(10)
		        .map(t -> t[0])
		        .mapToInt(Integer::intValue)
		        .reduce(0,Integer::sum);
		        

	  System.out.println("Total sum of Fibonocci series is : " + sum);
			return sum;
		    
	}
	    


}
