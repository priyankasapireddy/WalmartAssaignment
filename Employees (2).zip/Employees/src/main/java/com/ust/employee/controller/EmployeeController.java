/**
 * Class: EmployeeController
 * 
 * Description: Controller class with autowiring service class for mapping 
 * 
 * date:10/12/2020
 */
package com.ust.employee.controller;

import static com.ust.employee.costant.ReportServiceConstant.*;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.employee.model.Employee;
import com.ust.employee.service.EmployeeService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * EmpController controller class by autowiring EmployeeService
 * 
 */

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	/**
	 * get mapping annotation can access getEmployeeList method internally
	 * 
	 * @return Flux<Employee>
	 **/
	@GetMapping(value = URL_MAPPING_GET_ALLEMPLOYEES)
	public List<Employee> getEmployeeList() {
		List<Employee> empList = service.getEmployeeList();
		return empList;
	}

	/**
	 * by @PostMapping we can add a employee
	 * 
	 * @param employee
	 * @return Employee
	 */
	@PostMapping(value = URL_MAPPING_POST_ADDEMPLOYEE)
	public Employee saveEmployee(@RequestBody Employee employee) {
		Employee newEmployee = service.saveEmployee(employee);
		return newEmployee;
	}

	/**
	 * by @GetMapping annotation we can get employee by name
	 * 
	 * @param name
	 * @return Flux<Employee>
	 */
	@GetMapping(value = URL_MAPPING_GET_EMPLOYEEBYNAME)
	public List<Employee> getEmployeeByName(@PathVariable("name") String name) {
		List<Employee> empList = service.getEmployeeByName(name);
		return empList;
	}

	/**
	 * getEmployeeByid method to get employee by using id as a parameter
	 * 
	 * @param id
	 * @return empList
	 */
	@GetMapping(value = URL_MAPPING_TO_GET_EMPLOYEEBYID)
	public Employee getEmployeeByid(@PathVariable("id") String id) {
		Employee empList = service.getEmployeeById(id);
		return empList;
	}

	/**
	 * by updateEmployee method we can update the employee details
	 * 
	 * @param employeeId
	 * @param employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_EMPLOYEEUPDATE, method = RequestMethod.PUT)
	public void updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {

		service.updateEmployee(employee);
	}

	/**
	 * updateBonousOfEmployee method we can update employee bonous
	 * 
	 * @param employeeId
	 * @param employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEBONOUS, method = RequestMethod.PUT)
	public void updateBonousOfEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {

		service.updateBonousOfEmployee(employee);
	}

	/**
	 * method assFreshers we can add list of freshers to employeeList
	 * 
	 * @param List<Employee> 
	 * @return  List<Employee> 
	 */

	@PostMapping(value = URL_MAPPING_POST_ADDFRESHERS)
	public List<Employee> addFreshers(@RequestBody List<Employee> employee) {

		List<Employee> empList = service.addFreshers(employee);

		return empList;

	}

	/**
	 * deleteEmployee method to delete employee by id
	 * 
	 * @param id
	 * 
	 */
	@RequestMapping(value = URL_MAPPING_DELETE_DELETEEMPLOYEE, method = RequestMethod.DELETE)
	public Employee deleteEmployeeByid(@PathVariable String id) {
		return service.deleteEmployeeById(id);
	}

	
	
	/**
	 * searchEmployeeWithId method to get Employee By using id as parameter through
	 * SQLQueries
	 * 
	 * @param id
	 * @return Mono<Employee>
	 */
	@GetMapping(value = URL_MAPPING_SEARCH_EMPLOYEE_BY__EMPLOYEEBYID)
	public Employee searchEmployeeWithId(@PathVariable("empId") String empId) {
		System.out.println(empId);
		Employee empList = service.searchEmployeeWithIdUsingQuery(empId);
		System.out.println(empList);
		return empList;
	}

	/**
	 * method to get employees with a limit based on account name through SQLQueries
	 * 
	 * @param account
	 * @param offset
	 * @param limit
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_TO_GET_EMPLOYEE_BY__LIMIT)
	public List<Employee> searchEmployeeUsingQueryWithLimit(@PathVariable("account") String account,
			@PathVariable("offset") Integer offset, @PathVariable("limit") Integer limit) {

		List<Employee> empList = service.searchEmployeeUsingQueryWithLimit(account, offset, limit);

		return empList;

	}

	/**
	 * searchEmployeeByQueryUsingRangeOfJoiningDate method to fetch employees
	 * between the range of given joining date
	 * 
	 * @param fromdate
	 * @param todate
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_TO_GET_EMPLOYEE_BY__JOININGDATE_RANGE)
	public List<Employee> searchEmployeeByQueryUsingRangeOfJoiningDate(@PathVariable("fromdate") String fromdate,
			@PathVariable("todate") String todate) {

		List<Employee> empList = service.searchEmployeeByQueryUsingRangeOfJoiningDate(fromdate, todate);

		return empList;

	}

}
