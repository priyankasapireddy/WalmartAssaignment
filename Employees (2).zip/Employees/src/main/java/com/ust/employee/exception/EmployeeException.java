/**
 * Class:EmployeeException
 * Description:Exception Class to handle  Exception in Employee application
 * Date:18/12/2020
 */

package com.ust.employee.exception;

/**
 * EmployeeException class that extends RuntimeException to use custom exception
 * 
 * @author sanga
 *
 */
public class EmployeeException extends RuntimeException {

	// auto generated serialVersionUID for conversion process
	private static final long serialVersionUID = 4508713387858082248L;

	// EmployeeException class parameterized constructor
	public EmployeeException(String message) {

		super(message);

	}

	// EmployeeException class non-parameterized constructor
	public EmployeeException() {
		super();
	}

}
