/**
 * Class: 
 * 
 * Description: Interface with @Resposity Interface
 * 
 * Date:15/12/2020
 */

package com.ust.employee.repo;

import org.springframework.stereotype.Repository;

import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.ust.employee.model.Employee;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
/**
 * Interface acts as repository and extends ReactiveCosmosRepository<Employee, Integer>
 * @author sanga
 *
 */
@Repository
public interface IEmployeeRepo extends ReactiveCosmosRepository<Employee, Integer> {


	
   
	Flux<Employee> getEmpByName(String name);

	void deleteById(String id);

	Mono<Employee> findById(String empId);

	void deleteByname(String name);

	Mono<Employee> findByName(String name);

	

	


	
}
