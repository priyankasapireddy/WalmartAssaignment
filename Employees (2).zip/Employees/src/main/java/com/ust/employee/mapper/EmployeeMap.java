/**
 * Class: EmployeeMap
 * Description: EmployeeMap class that maps data from DB 
 * Date:22/12/2020
 */
package com.ust.employee.mapper;

import org.springframework.stereotype.Component;

import com.ust.employee.model.Employee;
@Component
public class EmployeeMap {
	/**
	 * method to map every employee data
	 * @param employee
	 * @return
	 */
	public Employee mapEmployeeDetail(Employee employee) {
		Employee emp = employee;
		return emp;
	}

}
