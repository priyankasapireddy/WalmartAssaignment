/**
 * Class : EmployeeDAO
 * Description: EmployeeDAOclass acts as component to implement the sql queries to connect to DB
 * Date:22/12/2020
 */
package com.ust.employee.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.azure.cosmos.models.SqlParameter;
import com.azure.cosmos.models.SqlQuerySpec;
import com.azure.cosmos.util.CosmosPagedIterable;

import com.ust.employee.costant.SQLQueries;
import com.ust.employee.mapper.EmployeeMap;
import com.ust.employee.model.Employee;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**EmployeeDAO class having methods to connect to DB
 * 
 * @author sanga
 *
 */
@Component
public class EmployeeDAO {

	@Value("${azure.cosmosdb.database}")
	private String databaseName;

	@Autowired
	private CosmosClientBuilder cosmosClientBuilder;

	@Autowired
	private EmployeeMap mapper;

	private String containerName = "employee";

	private SqlParameter tojoiningDate;

	private CosmosQueryRequestOptions getQueryOptions() {
		CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
		options.setQueryMetricsEnabled(Boolean.FALSE);
		return options;
	}

	/**
	 * Method for fetching an employee from DB using employeeId.
	 * 
	 * @param employeeId
	 * @return Employee
	 */
	public Employee getEmployeesWithId(String id) {
		String query = SQLQueries.FETCH_EMPLOYEE_WITH_ID;
		SqlQuerySpec querySpec = new SqlQuerySpec();
		querySpec.setQueryText(query);
		SqlParameter empId1 = new SqlParameter("@id", id);

		System.out.println("id in dao class :" + empId1);

		List<SqlParameter> paramList = new ArrayList<>();
		paramList.add(empId1);
		querySpec.setParameters(paramList);

		CosmosPagedIterable<Employee> employeeList = cosmosClientBuilder.buildClient().getDatabase(databaseName)
				.getContainer(containerName).queryItems(querySpec, getQueryOptions(), Employee.class);

		Employee emp = employeeList.stream().map(mapper::mapEmployeeDetail).findAny().orElse(null);

		System.out.println("emp in dao class returned  :" + emp);

		return emp;
	}

	/**
	 * Method for fetching employees from DB using account name within in a limit.
	 * 
	 * @param account
	 * @param offset
	 * @param limit
	 * @return List<Employee>
	 */
	public List<Employee> getEmployeesWithLimit(String account, Integer offset, Integer limit) {
		String query = SQLQueries.FETCH_ALL_WITH_LIMIT;

		SqlQuerySpec querySpec = new SqlQuerySpec();
		querySpec.setQueryText(query);
		SqlParameter accountName = new SqlParameter("@account", account);
		SqlParameter offsetParam = new SqlParameter("@offset", offset);
		SqlParameter limitParam = new SqlParameter("@limit", limit);
		List<SqlParameter> paramList = new ArrayList<>();
		paramList.add(accountName);
		paramList.add(offsetParam);
		paramList.add(limitParam);
		querySpec.setParameters(paramList);

		CosmosPagedIterable<Employee> employeeList = cosmosClientBuilder.buildClient().getDatabase(databaseName)
				.getContainer(containerName).queryItems(querySpec, getQueryOptions(), Employee.class);

		List<Employee> empList = employeeList.stream().map(mapper::mapEmployeeDetail).collect(Collectors.toList());

		return empList;
	}

	/**
	 * method for fetching employees from DB using joining date within in a range
	 * 
	 * @param fromdate
	 * @param todate
	 * @return List<Employee>
	 */
	public List<Employee> getEmployeesBetweenjoiningdateRange(String fromdate, String todate) {

		String query = SQLQueries.FETCH_EMPLOYEE_USING_JOININGDATE;

		SqlQuerySpec querySpec = new SqlQuerySpec();

		querySpec.setQueryText(query);

		SqlParameter fromdate1 = new SqlParameter("@fromdate", fromdate);
		SqlParameter todate1 = new SqlParameter("@todate", todate);

		List<SqlParameter> paramList = new ArrayList<>();

		paramList.add(fromdate1);
		paramList.add(todate1);

		querySpec.setParameters(paramList);

		CosmosPagedIterable<Employee> employeeList = cosmosClientBuilder.buildClient().getDatabase(databaseName)
				.getContainer(containerName).queryItems(querySpec, getQueryOptions(), Employee.class);

		List<Employee> empList = employeeList.stream().map(mapper::mapEmployeeDetail).collect(Collectors.toList());

		return empList;

	}

}
