/**
 * Class: EmployeeService
 * Description:EmployeeService class for implementing methods using repository
 * Date:10/12/2020
 */

package com.ust.employee.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import static com.ust.employee.costant.ReportServiceConstant.*;


import com.ust.employee.dao.EmployeeDAO;
import com.ust.employee.exception.EmployeeException;
import com.ust.employee.model.Employee;
import com.ust.employee.repo.IEmployeeRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * EmployeeService class for implementing methods using repository which is
 * autowired
 * 
 * @author sanga
 *
 */
@Service
public class EmployeeService {

	@Autowired
	private IEmployeeRepo repo;

	@Autowired
	private EmployeeDAO dao;

	/**
	 * method that return all the employee list
	 * 
	 * @return
	 */

	public List<Employee> getEmployeeList() {

		Flux<Employee> employeeList = repo.findAll();

		List<Employee> empList = employeeList.collectList().block();

		return empList;

	}

	/**
	 * method that used to add a employee
	 * 
	 * @param employee
	 * @return Employee
	 */
	public Employee saveEmployee(Employee employee) {

		Mono<Employee> savedEmployee = repo.save(employee);

		if (savedEmployee == null) {

			throw new EmployeeException(ADDED_EMPLOYEE_NULL);

		} else {

			Employee saveEmployee = savedEmployee.block();

			return saveEmployee;
		}

	}

	/**
	 * method to get employee by name as paramenter
	 * 
	 * @param name
	 * @return
	 */
	public List<Employee> getEmployeeByName(String name) {

		Flux<Employee> employeeList = repo.getEmpByName(name);

		if (employeeList == null) {
			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);

		} else {

			List<Employee> employee = employeeList.collectList().block();
			return employee;
		}
	}

	/**
	 * method to get employee by giving id as parameter
	 * 
	 * @param id
	 * 
	 * @return Employee
	 */

	public Employee getEmployeeById(String id) {

		Mono<Employee> employeeMono = repo.findById(id);

		if (employeeMono == null) {
			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);

		} else {
			Employee employee = employeeMono.block();

			return employee;
		}

	}

	/**
	 * method that delete the employee by id as parameter
	 * 
	 * @param id
	 * @return
	 */
	public Employee deleteEmployeeById(String id) {

		Mono<Employee> findByIdMono = repo.findById(id);

		Employee findByIdEmployee = findByIdMono.block();

		if (findByIdEmployee == null) {
			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);

		} else {
			
			repo.delete(findByIdEmployee).block();

			return findByIdEmployee;
		}

	}

	
	/**
	 * method used to update employees bonous and experience
	 * 
	 * @param employee
	 * @return
	 */
	public Employee updateEmployee(Employee updateEmployee) {

		Employee savedEmp = null;

		Mono<Employee> fetchEmployeeFromDb = repo.findById(updateEmployee.getId());

		Employee employeeInDb = fetchEmployeeFromDb.block();

		if (employeeInDb == null) {

			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);
		}

		else {
			repo.delete(employeeInDb).block();

			employeeInDb.setExperience(updateEmployee.getExperience());

			employeeInDb.setBand(updateEmployee.getBand());

			Mono<Employee> savedEmpMono = repo.save(employeeInDb);

			savedEmp = savedEmpMono.block();
		}

		/*
		 * Employee savedEmp = null;
		 * 
		 * Mono<Employee> fetchEmployeeFromDb =
		 * repo.findByName(updateEmployee.getName()); Employee employeeInDb =
		 * fetchEmployeeFromDb.block();
		 * 
		 * Mono<Employee> del = fetchEmployeeFromDb.flatMap(each ->
		 * repo.delete(each).then(Mono.just(each)));
		 * 
		 * System.out.println("update employee method" + employeeInDb);
		 * 
		 * if (employeeInDb != null) {
		 * 
		 * System.out.println("update employee method" + employeeInDb);
		 * employeeInDb.setExperience(updateEmployee.getExperience());
		 * employeeInDb.setBonous(updateEmployee.getBonous());
		 * 
		 * Mono<Employee> savedEmpMono = repo.save(employeeInDb);
		 * 
		 * savedEmp = savedEmpMono.block(); }
		 */
		return savedEmp;
	}

	/**
	 * Method to update employee bonous
	 * 
	 * @param updateEmployee
	 * @return Employee
	 */
	public Employee updateBonousOfEmployee(Employee updateEmployee) {

		Employee savedEmp = null;

		Mono<Employee> fetchEmployeeFromDb = repo.findById(updateEmployee.getId());

		Employee employeeInDb = fetchEmployeeFromDb.block();

		if (employeeInDb == null) {

			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);
		}

		else {
			repo.delete(employeeInDb).block();

			employeeInDb.setBonous(updateEmployee.getBonous());

			Mono<Employee> savedEmpMono = repo.save(employeeInDb);

			savedEmp = savedEmpMono.block();
			return savedEmp;
		}

	}

	/**
	 * method used to add list of employees more than one at a time
	 * 
	 * @param List<Employee>
	 * @return List<Employee>
	 */
	public List<Employee> addFreshers(List<Employee> employee) {

		Flux<Employee> saveEmp = repo.saveAll(employee);

		if (saveEmp == null) {

			throw new EmployeeException(ADDED_EMPLOYEE_NULL);
		}

		else {
			List<Employee> employeeList = saveEmp.collectList().block();
			return employeeList;
		}
	}

	/**
	 * method to internally calls dao class and fetch the employee with id as
	 * parameter using SQL queries
	 * 
	 * @param empId
	 * @return Employee
	 */
	public Employee searchEmployeeWithIdUsingQuery(String empId) {

		Employee employee = dao.getEmployeesWithId(empId);

		System.out.println("service class  to search emp with id  :" + employee);

		if (employee == null) {
			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);
		}

		else {
			return employee;

		}
	}

	/**
	 * method to internally calls dao class and fetch the employees within a range
	 * for given account name using SQL queries
	 * 
	 * @param account
	 * @param offset
	 * @param limit
	 * @return List<Employee>
	 */
	public List<Employee> searchEmployeeUsingQueryWithLimit(String account, Integer offset, Integer limit) {

		List<Employee> employee = dao.getEmployeesWithLimit(account, offset, limit);

		System.out.println("service class employee list with limit method :" + employee);

		if (employee == null) {
			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);
		}

		else {
			return employee;

		}
	}

	/**
	 * method to internally calls dao class and fetch the employees between given
	 * range of joining dates
	 * 
	 * @param fromdate
	 * @param todate
	 * @return List<Employee>
	 */
	public List<Employee> searchEmployeeByQueryUsingRangeOfJoiningDate(String fromdate, String todate) {

		List<Employee> employee = dao.getEmployeesBetweenjoiningdateRange(fromdate, todate);

		if (employee == null) {
			throw new EmployeeException(CONFLICT_EMPLOYEE_NOT_FOUND);
		}

		else {
			return employee;

		}
	}

}
