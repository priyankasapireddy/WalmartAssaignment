/**
 * Class: EmployeeService
 * Description:EmployeeService class for implementing methods using repository
 * Date:10/12/2020
 */

package com.ust.employee.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import com.ust.employee.model.Employee;
import com.ust.employee.repo.IEmployeeRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * EmployeeService class for implementing methods using repository by autowiring
 * 
 * @author sanga
 *
 */
@Service

public class EmployeeService {

	@Autowired
	private IEmployeeRepo repo;

	/**
	 * method that return all the employee list
	 * 
	 * @return
	 */

	public Flux<Employee> getEmployeeList() {

		Flux<Employee> employeeList = repo.findAll();
		return employeeList;
	}

	/**
	 * method that used to add a employee
	 * 
	 * @param employee
	 * @return
	 */
	public Mono<Employee> saveEmployee(Employee employee) {
		Mono<Employee> savedEmployee = repo.save(employee);
		return savedEmployee;
	}

	/**
	 * method to get employee by name as paramenter
	 * 
	 * @param name
	 * @return
	 */
	public Flux<Employee> getEmployeeByName(String name) {
		Flux<Employee> employeeList = repo.getEmpByName(name);
		return employeeList;
	}

	/**
	 * method to get employee by giving id as parameter
	 * 
	 * @param id
	 * @return Mono<Employee>
	 */

	public Mono<Employee> getEmployeeById(String id) {

		Mono<Employee> employeeList = repo.findById(id);

		return employeeList;
	}

	/**
	 * method that delete the employee by id as parameter
	 * 
	 * @param id
	 * @return
	 */
	public String deleteEmployeeById(String id) {

		Mono<Employee> findByIdMono = repo.findById(id);
		
		Employee findByIdEmployee = findByIdMono.block();
		
		repo.delete(findByIdEmployee).block();
		
		return null;
	}

	/**
	 * method used to update employees bonous and experience
	 * 
	 * @param employee
	 * @return
	 */
	public Employee updateEmployee(Employee updateEmployee) {
		
		Employee savedEmp = null;
		
		Mono<Employee> fetchEmployeeFromDb = repo.findById(updateEmployee.getId());
		
		Employee employeeInDb = fetchEmployeeFromDb.block();
		
		System.out.println("update employee method" + employeeInDb);

		if (employeeInDb != null) {
			
			repo.delete(employeeInDb).block();

			System.out.println("update employee method" + employeeInDb);
			
			employeeInDb.setExperience(updateEmployee.getExperience());
			
			employeeInDb.setBonous(updateEmployee.getBonous());

			Mono<Employee> savedEmpMono = repo.save(employeeInDb);

			savedEmp = savedEmpMono.block();
		}

		
		

		

//		Employee savedEmp = null;
//
//		Mono<Employee> fetchEmployeeFromDb = repo.findByName(updateEmployee.getName());
//		Employee employeeInDb = fetchEmployeeFromDb.block();
//
//		Mono<Employee> del = fetchEmployeeFromDb.flatMap(each -> repo.delete(each).then(Mono.just(each)));
//
//		System.out.println("update employee method" + employeeInDb);
//
//		if (employeeInDb != null) {
//
//			System.out.println("update employee method" + employeeInDb);
//			employeeInDb.setExperience(updateEmployee.getExperience());
//			employeeInDb.setBonous(updateEmployee.getBonous());
//
//			Mono<Employee> savedEmpMono = repo.save(employeeInDb);
//
//			savedEmp = savedEmpMono.block();
//		}
//
		return savedEmp;
	}

	/**
	 * method used to add  list of employees more than one at a time
	 * 
	 * @param List<Employee>
	 * @return Flux<Employee>
	 */
	public Flux<Employee> addFreshers(List<Employee> employee) {

		Flux<Employee> saveEmp = repo.saveAll(employee);

		return saveEmp;
	}

}
