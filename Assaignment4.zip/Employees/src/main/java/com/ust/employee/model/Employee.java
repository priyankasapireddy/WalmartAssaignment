/**
 * Class:Employee 
 * Description: Model class Employee contains all parameters and getter and setter methods 
 * Date:10/12/2020
 */
package com.ust.employee.model;



import org.springframework.data.annotation.Id;



import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;

import lombok.Data;

/**
 * Model class Employee contains all parameters and getter and setter methods
 * 
 * @author sanga
 *
 */
@Document(collection = "employee")
@Data

public class Employee {

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empId=" + empId + ", name=" + name + ", account=" + account + ", band=" + band
				+ ", department=" + department + ", salary=" + salary + ", experience=" + experience + ", bonous="
				+ bonous + ", joiningdate=" + joiningdate + "]";
	}

	@Id
	
	private String id;

	private Integer empId;
	
	private String name;

	private String account;

	private String band;
	
	private String department;

	private int salary;
	
	private int experience;

	private int bonous;
	
	private String joiningdate;

	/**
	 * Employee Non-parameterised constructor
	 */
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Employee parameterised constructor
	 */
	public Employee(String id, Integer empId, String name, String account, String band, String department, int salary,
			int experience, int bonous, String joiningdate) {
		super();
		this.id = id;
		this.empId = empId;
		this.name = name;
		this.account = account;
		this.band = band;
		this.department = department;
		this.salary = salary;
		this.experience = experience;
		this.bonous = bonous;
		this.joiningdate = joiningdate;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public int getSalary() {
		return salary;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setSalary(int salary) {
		this.salary = salary;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public int getBonous() {
		return bonous;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setBonous(int bonous) {
		this.bonous = bonous;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public String getJoiningdate() {
		return joiningdate;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setJoiningdate(String joiningdate) {
		this.joiningdate = joiningdate;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public Integer getEmpId() {
		return empId;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public String getAccount() {
		return account;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setAccount(String account) {
		this.account = account;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public String getBand() {
		return band;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setBand(String band) {
		this.band = band;
	}

	/**
	 * getter method
	 * 
	 * @return
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * setter method
	 * 
	 * @return
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

}
