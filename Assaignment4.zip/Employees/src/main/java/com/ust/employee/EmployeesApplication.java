/**
 * Class: EmployeesApplication
 * Description:EmployeesApplication class contains main method to run employee application
 * Date:12/10/2020
 */
package com.ust.employee;

import org.springframework.boot.SpringApplication;
import static com.ust.employee.costant.ReportServiceConstant.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

/**
 * EmployeesApplication class contains main method to run employee application
 * @author sanga
 *
 */


@SpringBootApplication
@EntityScan(basePackages = EMPLOYEE_BASE_PACKAGE) 

public class EmployeesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeesApplication.class, args);
		
		
	}

}
