package com.ust.employee.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.microsoft.azure.spring.data.cosmosdb.repository.ReactiveCosmosRepository;
import com.ust.employee.model.Employee;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface IEmployeeRepo extends ReactiveCosmosRepository<Employee, Integer> {


	

	Flux<Employee> getEmpByName(String name);

	void deleteById(String id);
	 

	


	
}
