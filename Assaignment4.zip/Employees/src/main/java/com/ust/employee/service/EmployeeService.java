/**
 * Class: EmployeeService
 * Description:EmployeeService class for implementing methods using repository
 * Date:10/12/2020
 */

package com.ust.employee.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ust.employee.model.Employee;
import com.ust.employee.repo.IEmployeeRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * EmployeeService class for implementing methods using repository by autowiring
 * 
 * @author sanga
 *
 */
@Service

public class EmployeeService {

	@Autowired
	private IEmployeeRepo repo;

	/**
	 * method that return all the employee list
	 * 
	 * @return
	 */

	public Flux<Employee> getEmployeeList() {

		Flux<Employee> employeeList =  repo.findAll();
		return employeeList;
	}

	/**
	 * method that used to add a employee
	 * 
	 * @param employee
	 * @return
	 */
	public Mono<Employee> saveEmployee(Employee employee) {
		Mono<Employee> savedEmployee = repo.save(employee);
		return savedEmployee;
	}

	/**
	 * method to get employee by name as paramenter
	 * 
	 * @param name
	 * @return
	 */
	public Flux<Employee> getEmployeeByName(String name) {
		Flux<Employee> employeeList = repo.getEmpByName(name);
		return employeeList;
	}

	/**
	 * method to get employee by id
	 */

	public Mono<Employee> getEmployeeByid(int id) {

		Mono<Employee> employeeList = repo.findById(id);
		return employeeList;
	}

	/**
	 * method that delete the employee by id as parameter
	 * 
	 * @param id
	 * @return
	 */
	public String deleteEmployeeById(String id) {
		repo.deleteById(id);
		return null;

	}

	/**
	 * method used to update employees band and experience
	 * 
	 * @param employee
	 * @return
	 */
	public Employee updateEmployee(Employee updateEmployee) {

		Employee savedEmp = null;

		Employee employee = new Employee();

		Mono<Employee> fetchEmployeeFromDb = repo.findById(updateEmployee.getEmpId());

		Employee employeeInDb = fetchEmployeeFromDb.block();

		if (employeeInDb != null) {

			repo.delete(employeeInDb).block();

			employee.setId(updateEmployee.getId());
			employee.setEmpId(updateEmployee.getEmpId());
			employee.setName(updateEmployee.getName());
			employee.setAccount(updateEmployee.getAccount());
			employee.setBand(updateEmployee.getBand());
			employee.setDepartment(updateEmployee.getDepartment());
			employee.setSalary(updateEmployee.getSalary());
			employee.setExperience(updateEmployee.getExperience());
			employee.setBonous(updateEmployee.getBonous());
			employee.setJoiningdate(updateEmployee.getJoiningdate());

			Mono<Employee> savedEmpMono = repo.save(employee);

			savedEmp = savedEmpMono.block();
		}else {
			
			employee.setId(updateEmployee.getId());
			employee.setEmpId(updateEmployee.getEmpId());
			employee.setName(updateEmployee.getName());
			employee.setAccount(updateEmployee.getAccount());
			employee.setBand(updateEmployee.getBand());
			employee.setDepartment(updateEmployee.getDepartment());
			employee.setSalary(updateEmployee.getSalary());
			employee.setExperience(updateEmployee.getExperience());
			employee.setBonous(updateEmployee.getBonous());
			employee.setJoiningdate(updateEmployee.getJoiningdate());

			Mono<Employee> savedEmpMono = repo.save(employee);

			savedEmp = savedEmpMono.block();
			
		}

		return savedEmp;

	}

//	/**
//	 * method used to update employees bonous
//	 * 
//	 * @param employee
//	 * @return Mono<Employee>
//	 */
//	public Mono<Employee> updateEmployeeBonous(Employee employee) {
//
//		Mono<Employee> emp = repo.findById(employee.getEmpId());
//		Mono<Employee> saveEmp = null;
//
//		if (emp.block() != null) {
//
//			Employee employee1 = emp.block();
//			employee1.setBonous(employee.getBonous());
//
//			saveEmp = repo.save(employee1);
//
//		}
//		return saveEmp;
//
//	}

	/**
	 * method used to add employees more than one at a time
	 * 
	 * @param List<Employee>
	 * @return Flux<Employee>
	 */
	public List<Employee> addFreshers(List<Employee> employee) {

		List<Employee> saveEmp = (List<Employee>) repo.saveAll(employee);

		return saveEmp;
	}

}
