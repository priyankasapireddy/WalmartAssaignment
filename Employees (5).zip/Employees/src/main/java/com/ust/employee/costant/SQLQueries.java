package com.ust.employee.costant;

public class SQLQueries {
	
	public static String FETCH_EMPLOYEE_WITH_ID = "select * from employee where employee.empId = @empId";

}
