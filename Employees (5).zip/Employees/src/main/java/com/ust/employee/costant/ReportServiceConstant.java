package com.ust.employee.costant;

public interface ReportServiceConstant {

	// base package

	public static final String EMPLOYEE_BASE_PACKAGE = "com.ust.employee";

	// mapping values
	public static final String URL_MAPPING_GET_ALLEMPLOYEES = "/employeeList";

	public static final String URL_MAPPING_GET_EMPLOYEEBYNAME = "/employeeList/{name}";

	public static final String URL_MAPPING_POST_ADDEMPLOYEE = "/addEmployee";

	public static final String URL_MAPPING_POST_ADDFRESHERS = "/addFreshers";

	public static final String  URL_MAPPING_PUT_EMPLOYEEUPDATE = "/updateEmployee/{employeeId}";

	public static final String URL_MAPPING_PUT_UPDATEBONOUS ="/updateBonous/{employeeId}";

	public static final String URL_MAPPING_DELETE_DELETEEMPLOYEE = "/deleteEmployee/{id}";
	
	public static final String URL_MAPPING_TO_GET_EMPLOYEEBYID ="/employeebyId/{id}";
	
	public static final String URL_MAPPING_SEARCH_EMPLOYEE_BY__EMPLOYEEBYID ="/employeeById/{empId}";
	
	//exception messages
	public static final String  CONFLICT_EMPLOYEE_NOT_FOUND  ="employee not found";
	
	public static final String  ADDED_EMPLOYEE_NULL ="Empty set added/null employees added";
	
	public static final String  EMPLOYEE_LIST_EMPTY ="Employee list is empty";
}
