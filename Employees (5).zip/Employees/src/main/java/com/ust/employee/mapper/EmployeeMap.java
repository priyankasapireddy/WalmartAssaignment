package com.ust.employee.mapper;

import org.springframework.stereotype.Component;

import com.ust.employee.model.Employee;
@Component
public class EmployeeMap {
	
	public Employee mapEmployeeDetail(Employee employee) {
		Employee emp = employee;
		return emp;
	}

}
