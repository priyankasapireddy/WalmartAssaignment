package com.ust.employee.dao;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.azure.cosmos.models.SqlParameter;
import com.azure.cosmos.models.SqlQuerySpec;
import com.azure.cosmos.util.CosmosPagedIterable;

import com.ust.employee.costant.SQLQueries;
import com.ust.employee.mapper.EmployeeMap;
import com.ust.employee.model.Employee;


@Component
public class EmployeeDAO {
	
	@Value("${azure.cosmosdb.database}")
	private String databaseName;

	@Autowired
	private CosmosClientBuilder cosmosClientBuilder;
	
	@Autowired
	private EmployeeMap mapper;
	
	
	private String containerName ="employee";

	private CosmosQueryRequestOptions getQueryOptions() {
		CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
		options.setQueryMetricsEnabled(Boolean.FALSE);
		return options;
	}
	
	public Employee getEmployeesWithId(String employeeId) {
		String query = SQLQueries.FETCH_EMPLOYEE_WITH_ID;
		SqlQuerySpec querySpec = new SqlQuerySpec();
		querySpec.setQueryText(query);
		SqlParameter employeeId1 = new SqlParameter("@empId", employeeId);
		List<SqlParameter> paramList = new ArrayList<>();
		paramList.add(employeeId1);
		querySpec.setParameters(paramList);

		CosmosPagedIterable<Employee> employeeList = cosmosClientBuilder
				.buildClient().getDatabase(databaseName)
				.getContainer(containerName)
				.queryItems(querySpec, getQueryOptions(), Employee.class);

		Employee emp = employeeList.stream().map(mapper::mapEmployeeDetail)
				.findAny().orElse(null);
				
		return emp;
	}
	
	

}
