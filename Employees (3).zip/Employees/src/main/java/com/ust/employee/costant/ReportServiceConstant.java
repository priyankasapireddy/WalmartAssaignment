package com.ust.employee.costant;

public interface ReportServiceConstant {

	// base package

	public static final String EMPLOYEE_BASE_PACKAGE = "com.ust.employee";

	// mapping values
	public static final String URL_MAPPING_GET_ALLEMPLOYEES = "/employeeList";

	public static final String URL_MAPPING_GET_EMPLOYEEBYNAME = "/employeeList/{name}";

	public static final String URL_MAPPING_POST_ADDEMPLOYEE = "/addEmployee";

	public static final String URL_MAPPING_POST_ADDFRESHERS = "/addFreshers";

	public static final String URL_MAPPING_PUT_EMPLOYEEUPDATE = "/updateEmployee/{empId}";

	public static final String URL_MAPPING_PUT_UPDATEBONOUS = "/updateBonous/{empId}";

	public static final String URL_MAPPING_DELETE_DELETEEMPLOYEE = "/deleteEmployee/{id}";

	public static final String URL_MAPPING_TO_GET_EMPLOYEEBYID = "/employeebyId/{id}";

	public static final String URL_MAPPING_SEARCH_EMPLOYEE_BY__EMPLOYEEBYID = "/employeeId/{empId}";

	public static final String URL_TO_GET_EMPLOYEE_BY__LIMIT = "/{account}/{offset}/{limit}";

	public static final String URL_TO_GET_EMPLOYEE_BY__JOININGDATE_RANGE = "/empployeefromandtodate/{fromdate}/{todate}";

	// exception messages
	public static final String CONFLICT_EMPLOYEE_NOT_FOUND = "employee you are searching  not found";

	public static final String ADDED_EMPLOYEE_NULL = "Empty set added/null employees added";

	public static final String EMPLOYEE_LIST_EMPTY = "Employee list is empty";

	// pathvariables
	public static final String EMPLOYEE_ID = "empId";
	public static final String EMPLOYEE_BAND = "band";
	public static final String EMPLOYEE_ACCOUNT_NAME = "account";
	public static final String ACCOUNT_NAME = "account";
	public static final String OFFSET_LIMIT = "offset";
	public static final String LIMIT = "limit";
	public static final String FROMDATE = "fromdate";
	public static final String TODATE = "todate";

	// Swagger Notes
	public static final String NOTES_FOR_SWAGGER = "Returns 200/204 Response";
	public static final String SWAGGER_NOTES = "Returns 201/409 Response";

	// ApiOperation value
	public static final String GET_EMPLOYEE_LIST_VALUE = "Fetch all employees";

	public static final String GET_EMPLOYEE_BY_ID = "Fetch employee by id";

	public static final String GET_EMPLOYEES_BY_NAME = "Fetch employees by name";

	public static final String ADD_AN_EMPLOYEE = "Add an employee";

	public static final String ADD_EMPLOYEES = "Add employees";

	public static final String DELETE_AN_EMPLOYEE_BY_ID = "Delete an  employee by id";

	public static final String UPDATE_AN_EMPLOYEE = "Update experience and band of an employee by employeeid";

	public static final String GET_EMPLOYEES_IN_JOININGDATE = "fetch employees in between given  joiningdate ";

	public static final String GET_EMPLOYEES_BY_ACCOUNTNAME = "Fetch employees by accountname";

	public static final String UPDATE_BONUS_EMPLOYEE = "update bonus to an employees";

	// ApiImplicitParams

	public static final String CONTENT_TYPE = "Content-Type";

	public static final String DATA_TYPE_STRING = "String";

	public static final String PARAM_HEADER = "header";

	public static final String USER_ID = "UserId";

	public static final String USER_MANDITORY = "User id is mandatory";

	// HttpServletResponse message
	public static final String RESPONSE_OK = "OK";

	public static final String RESPONSE_CONFLICT = "CONFLICT";

	public static final String RESPONSE_NO_CONTENT = "NO CONTENT";
}
