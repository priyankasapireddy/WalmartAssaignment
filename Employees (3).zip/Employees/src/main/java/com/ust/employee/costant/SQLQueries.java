package com.ust.employee.costant;

public class SQLQueries {
	
	public static String FETCH_EMPLOYEE_WITH_ID = "select * from employee where employee.id = @id";
	
	public static String FETCH_ALL_WITH_LIMIT = "select * from employee where employee.account = @account offset @offset limit @limit";
    
	public static String FETCH_EMPLOYEE_USING_JOININGDATE ="select * from employee where  employee.joiningdate between @fromdate AND @todate " ;
			
			
}
