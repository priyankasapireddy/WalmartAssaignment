/**
 * Class: EmployeeController
 * 
 * Description: Controller class with autowiring service class for mapping 
 * 
 * date:10/12/2020
 */
package com.ust.employee.controller;

import static com.ust.employee.costant.ReportServiceConstant.GET_EMPLOYEE_LIST_VALUE;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_DELETE_DELETEEMPLOYEE;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_GET_ALLEMPLOYEES;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_GET_EMPLOYEEBYNAME;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_POST_ADDEMPLOYEE;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_POST_ADDFRESHERS;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_PUT_EMPLOYEEUPDATE;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_PUT_UPDATEBONOUS;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_SEARCH_EMPLOYEE_BY__EMPLOYEEBYID;
import static com.ust.employee.costant.ReportServiceConstant.URL_MAPPING_TO_GET_EMPLOYEEBYID;
import static com.ust.employee.costant.ReportServiceConstant.URL_TO_GET_EMPLOYEE_BY__JOININGDATE_RANGE;
import static com.ust.employee.costant.ReportServiceConstant.URL_TO_GET_EMPLOYEE_BY__LIMIT;
import static com.ust.employee.costant.ReportServiceConstant.GET_EMPLOYEES_BY_NAME;
import static com.ust.employee.costant.ReportServiceConstant.ADD_EMPLOYEES;
import static com.ust.employee.costant.ReportServiceConstant.DELETE_AN_EMPLOYEE_BY_ID;
import static com.ust.employee.costant.ReportServiceConstant.GET_EMPLOYEES_BY_ACCOUNTNAME;
import static com.ust.employee.costant.ReportServiceConstant.GET_EMPLOYEE_BY_ID;
import static com.ust.employee.costant.ReportServiceConstant.UPDATE_AN_EMPLOYEE;
import static com.ust.employee.costant.ReportServiceConstant.UPDATE_BONUS_EMPLOYEE;
import static com.ust.employee.costant.ReportServiceConstant.GET_EMPLOYEES_IN_JOININGDATE;
import static com.ust.employee.costant.ReportServiceConstant.ACCOUNT_NAME;
import static com.ust.employee.costant.ReportServiceConstant.LIMIT;
import static com.ust.employee.costant.ReportServiceConstant.OFFSET_LIMIT;
import static com.ust.employee.costant.ReportServiceConstant.ADD_AN_EMPLOYEE;
import static com.ust.employee.costant.ReportServiceConstant.TODATE;
import static com.ust.employee.costant.ReportServiceConstant.FROMDATE;
import static com.ust.employee.costant.ReportServiceConstant.EMPLOYEE_ID;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.employee.controller.annoatation.SwaggerToken;
import com.ust.employee.costant.ReportServiceConstant;
import com.ust.employee.exception.EmployeeException;
import com.ust.employee.model.Employee;
import com.ust.employee.service.EmployeeService;

import io.swagger.annotations.ApiOperation;

/**
 * EmpController controller class by autowiring EmployeeService
 * 
 */

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	/**
	 * get mapping annotation can access getEmployeeList method internally
	 * 
	 * @return Flux<Employee>
	 **/
	@GetMapping(value = URL_MAPPING_GET_ALLEMPLOYEES)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEE_LIST_VALUE, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.GET)
	public ResponseEntity<List<Employee>> getEmployeeList() {

		ResponseEntity<List<Employee>> response = null;

		List<Employee> empList = service.getEmployeeList();

		if (!CollectionUtils.isEmpty(empList)) {

			List<Employee> employeeList = new ArrayList<Employee>();

			empList.forEach(eachEmp -> {

				Employee emp = new Employee();

				BeanUtils.copyProperties(eachEmp, emp);

				employeeList.add(emp);
			});
			response = ResponseEntity.ok(employeeList);
		}
		return response;

	}

	/**
	 * by @PostMapping we can add a employee
	 * 
	 * @param employee
	 * @return Employee
	 */
	@PostMapping(value = URL_MAPPING_POST_ADDEMPLOYEE)
	@SwaggerToken
	@ApiOperation(value = ADD_AN_EMPLOYEE, notes = ReportServiceConstant.SWAGGER_NOTES, httpMethod = javax.ws.rs.HttpMethod.POST)
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) throws EmployeeException {

		ResponseEntity<Employee> response = null;

		Employee newEmployee = service.saveEmployee(employee);

		if (newEmployee != null) {

			Employee emp = new Employee();

			BeanUtils.copyProperties(newEmployee, emp);

			response = new ResponseEntity<Employee>(emp, HttpStatus.CREATED);

		}
		return response;

	}

	/**
	 * by @GetMapping annotation we can get employee by name
	 * 
	 * @param name
	 * @return Flux<Employee>
	 */
	@GetMapping(value = URL_MAPPING_GET_EMPLOYEEBYNAME)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEES_BY_NAME, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.GET)
	public ResponseEntity<List<Employee>> getEmployeeByName(@PathVariable("name") String name) {

		ResponseEntity<List<Employee>> response = null;

		List<Employee> empList = service.getEmployeeByName(name);

		response = ResponseEntity.ok(empList);

		return response;
	}

	/**
	 * getEmployeeByid method to get employee by using id as a parameter
	 * 
	 * @param id
	 * @return empList
	 */
	@GetMapping(value = URL_MAPPING_TO_GET_EMPLOYEEBYID)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEE_BY_ID, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.GET)
	public ResponseEntity<Employee> getEmployeeByid(@PathVariable("id") String id) {

		ResponseEntity<Employee> response = null;

		Employee empList = service.getEmployeeById(id);

		if (empList != null) {
			response = ResponseEntity.ok(empList);
		}
		return response;
	}

	/**
	 * by updateEmployee method we can update the employee details
	 * 
	 * @param employeeId
	 * @param employee
	 * @return
	 */
	@RequestMapping(value = URL_MAPPING_PUT_EMPLOYEEUPDATE, method = RequestMethod.PUT)
	@SwaggerToken
	@ApiOperation(value = UPDATE_AN_EMPLOYEE, notes = ReportServiceConstant.SWAGGER_NOTES, httpMethod = javax.ws.rs.HttpMethod.POST)
	public ResponseEntity<Employee> updateEmployee(@PathVariable int EMPLOYEE_ID, @RequestBody Employee employee) {

		ResponseEntity<Employee> response = null;

		Employee emp = service.updateEmployee(employee);

		if (emp != null) {

			response = new ResponseEntity<Employee>(emp, HttpStatus.OK);
		}
		return response;

	}

	/**
	 * updateBonousOfEmployee method we can update employee bonous
	 * 
	 * @param employeeId
	 * @param employee
	 * @return
	 */

	@RequestMapping(value = URL_MAPPING_PUT_UPDATEBONOUS, method = RequestMethod.PUT)
	@SwaggerToken
	@ApiOperation(value = UPDATE_BONUS_EMPLOYEE, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.POST)
	public ResponseEntity<Employee> updateBonousOfEmployee(@PathVariable int empId, @RequestBody Employee employee) {

		ResponseEntity<Employee> response = null;

		Employee emp = service.updateBonousOfEmployee(employee);

		if (emp != null) {

			response = new ResponseEntity<Employee>(emp, HttpStatus.OK);
		}
		return response;
	}

	/**
	 * method assFreshers we can add list of freshers to employeeList
	 * 
	 * @param List<Employee>
	 * @return List<Employee>
	 */

	@PostMapping(value = URL_MAPPING_POST_ADDFRESHERS)
	@SwaggerToken
	@ApiOperation(value = ADD_EMPLOYEES, notes = ReportServiceConstant.SWAGGER_NOTES, httpMethod = javax.ws.rs.HttpMethod.POST)
	public ResponseEntity<List<Employee>> addFreshers(@RequestBody List<Employee> employee) {

		ResponseEntity<List<Employee>> response = null;
		List<Employee> empList = service.addFreshers(employee);

		if (empList != null) {

			response = new ResponseEntity<List<Employee>>(empList, HttpStatus.CREATED);

		}
		return response;

	}

	/**
	 * deleteEmployee method to delete employee by id
	 * 
	 * @param id
	 * 
	 */
	@RequestMapping(value = URL_MAPPING_DELETE_DELETEEMPLOYEE, method = RequestMethod.DELETE)
	@SwaggerToken
	@ApiOperation(value = DELETE_AN_EMPLOYEE_BY_ID, notes = ReportServiceConstant.SWAGGER_NOTES, httpMethod = javax.ws.rs.HttpMethod.DELETE)
	public ResponseEntity<Employee> deleteEmployeeByid(@PathVariable String id) {
		ResponseEntity<Employee> response = null;

		Employee emp = service.deleteEmployeeById(id);
		if (emp != null) {

			response = new ResponseEntity<Employee>(emp, HttpStatus.OK);
		}
		return response;
	}

	/**
	 * searchEmployeeWithId method to get Employee By using id as parameter through
	 * SQLQueries
	 * 
	 * @param id
	 * @return Mono<Employee>
	 */
	@GetMapping(value = URL_MAPPING_SEARCH_EMPLOYEE_BY__EMPLOYEEBYID)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEE_BY_ID, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.GET)
	public ResponseEntity<Employee> searchEmployeeWithId(@PathVariable(EMPLOYEE_ID) String empId) {

		ResponseEntity<Employee> response = null;

		Employee empList = service.searchEmployeeWithIdUsingQuery(empId);

		if (empList != null) {
			response = new ResponseEntity<Employee>(empList, HttpStatus.OK);
		}
		return response;

	}

	/**
	 * method to get employees with a limit based on account name through SQLQueries
	 * 
	 * @param account
	 * @param offset
	 * @param limit
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_TO_GET_EMPLOYEE_BY__LIMIT)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEES_BY_ACCOUNTNAME, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.GET)
	public ResponseEntity<List<Employee>> searchEmployeeUsingQueryWithLimit(@PathVariable(ACCOUNT_NAME) String account,
			@PathVariable(OFFSET_LIMIT) int offset, @PathVariable(LIMIT) int limit) {

		ResponseEntity<List<Employee>> response = null;

		List<Employee> empList = service.searchEmployeeUsingQueryWithLimit(account, offset, limit);

		if (empList != null) {

			response = ResponseEntity.ok(empList);
		}
		return response;

	}

	/**
	 * searchEmployeeByQueryUsingRangeOfJoiningDate method to fetch employees
	 * between the range of given joining date
	 * 
	 * @param fromdate
	 * @param todate
	 * @return List<Employee>
	 */
	@GetMapping(value = URL_TO_GET_EMPLOYEE_BY__JOININGDATE_RANGE)
	@SwaggerToken
	@ApiOperation(value = GET_EMPLOYEES_IN_JOININGDATE, notes = ReportServiceConstant.NOTES_FOR_SWAGGER, httpMethod = javax.ws.rs.HttpMethod.GET)
	public ResponseEntity<List<Employee>> searchEmployeeByQueryUsingRangeOfJoiningDate(
			@PathVariable(FROMDATE) String fromdate, @PathVariable(TODATE) String todate) {

		ResponseEntity<List<Employee>> response = null;

		List<Employee> empList = service.searchEmployeeByQueryUsingRangeOfJoiningDate(fromdate, todate);

		if (empList != null) {

			response = ResponseEntity.ok(empList);
		}
		return response;

	}

}
