package com.ust.employee.controller.annoatation;



import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.servlet.http.HttpServletResponse;
import com.ust.employee.costant.ReportServiceConstant;
import static com.ust.employee.costant.ReportServiceConstant.*;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Inherited
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@ApiImplicitParams({
		@ApiImplicitParam(name = CONTENT_TYPE, value = CONTENT_TYPE, dataType = DATA_TYPE_STRING, paramType = PARAM_HEADER)})
	
@ApiResponses(value = {
		@ApiResponse(code = HttpServletResponse.SC_OK, message = RESPONSE_OK),
		@ApiResponse(code = HttpServletResponse.SC_CONFLICT, message = RESPONSE_CONFLICT),
		@ApiResponse(code = HttpServletResponse.SC_NO_CONTENT, message = RESPONSE_NO_CONTENT) })
public @interface SwaggerToken {

}
