package com.ust.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.ust.employee.dao.EmployeeDAO;
import com.ust.employee.model.Employee;
import com.ust.employee.repo.IEmployeeRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

//@RunWith(SpringRunner.class)
@SpringBootTest
class EmployeeServiceTest {

	@InjectMocks
	EmployeeService service;

	@Mock
	IEmployeeRepo repo;

	@Mock
	EmployeeDAO dao;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void testGetEmpList() {

		Mockito.when(repo.findAll()).thenReturn(getSampleEmployee());
		List<Employee> empList = service.getEmployeeList();
		Assert.assertEquals(2, empList.size());
		Assert.assertEquals("pinky", empList.get(0).getName());
	}

	@Test
	public void testSearchById() throws Exception {

		String id = "ust6";

		Mockito.when(repo.findById(id)).thenReturn(getMonoEmployee());

		Employee employee = service.getEmployeeById("ust6");

		Assert.assertEquals("raju", employee.getName());
	}

	@Test
	public void testsaveEmployee() throws Exception {

		Mockito.when(repo.save(Mockito.any())).thenReturn(getMonoEmployee());

		Employee employee = service.saveEmployee(new Employee());

		Assert.assertEquals("raju", employee.getName());

	}

	@Test
	public void testgetEmployeeByName() {

		Mockito.when(repo.getEmpByName(Mockito.any())).thenReturn(getSampleEmployee());

		List<Employee> employee = service.getEmployeeByName("pinky");

		Assert.assertEquals("pinky", employee.get(0).getName());

	}

	@Test
	public void testDeleteEmployee() throws Exception {

		String id = "ust6";
		Mockito.when(repo.findById(id)).thenReturn(getMonoEmployee());
		Mockito.when(repo.delete(Mockito.any())).thenReturn(Mono.empty());
		Employee emp = service.deleteEmployeeById("ust6");
		Assert.assertEquals("raju", emp.getName());
	}

	@Test
	public void testAddFresherEmployee() {

		Mockito.when(repo.saveAll(Mockito.<List<Employee>>any())).thenReturn(getSampleEmployee());

		List<Employee> empList = service.addFreshers(getSampleEmployeeList());

		Assert.assertEquals(2, empList.size());
	}

	@Test
	public void testgetEmployeesWithIdusingQuery() {
		Mockito.when(dao.getEmployeesWithId(Mockito.any()))
				.thenReturn(new Employee("ust6", "116", "raju", "walmart", "band3", "cec", 20000, 8, 1200, "2020-1-1"));
		Employee employee = service.searchEmployeeWithIdUsingQuery("ust6");
		Assert.assertEquals("raju", employee.getName());
	}

	@Test
	public void testgetEmployeesWithLimitUsingQuery() {
		Mockito.when(dao.getEmployeesWithLimit(Mockito.any(), Mockito.anyInt(), Mockito.anyInt()))
				.thenReturn(getSampleEmployeeList());

		List<Employee> employee = service.searchEmployeeUsingQueryWithLimit("Ust2", 1, 2);

		Assert.assertEquals(2, employee.size());
	}

	@Test
	public void testsearchEmployeeByQueryUsingRangeOfJoiningDate() {

		Mockito.when(dao.getEmployeesBetweenjoiningdateRange(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getSampleEmployeeList());

		List<Employee> employee = service.searchEmployeeByQueryUsingRangeOfJoiningDate("2020-1-1", "2020-12-31");

		Assert.assertEquals("2020-1-1", employee.get(0).getJoiningdate());

	}

	private Flux<Employee> getSampleEmployee() {

		Employee employee1 = new Employee("ust2", "112", "pinky", "walmart", "band2", "mech", 20000, 8, 1200,
				"2020-10-1");

		Employee employee2 = new Employee("ust6", "116", "raju", "walmart", "band3", "cec", 20000, 8, 1200,
				"2020-11-1");

		return Flux.just(employee1, employee2);
	}

	private List<Employee> getSampleEmployeeList() {

		List<Employee> employeeList = new ArrayList<Employee>();

		employeeList.add(new Employee("ust2", "112", "pinky", "walmart", "band2", "mech", 20000, 8, 1200, "2020-1-1"));

		employeeList.add(new Employee("ust6", "116", "raju", "walmart", "band3", "cec", 20000, 8, 1200, "2020-1-1"));

		return employeeList;

	}

	private Mono<Employee> getMonoEmployee() {

		Employee employee1 = new Employee("ust6", "116", "raju", "walmart", "band3", "cec", 20000, 8, 1200, "2020-1-1");

		return Mono.just(employee1);
	}

}
