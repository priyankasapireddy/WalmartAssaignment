/**
 * Interface: IEmployeeRepo
 * 
 * Description: IEmployeeRepo a repository contains methods defined 
 * 
 * Date:10/12/2020
 */

package com.ust.employee.repo;

import org.springframework.stereotype.Repository;

import com.microsoft.azure.spring.data.cosmosdb.repository.ReactiveCosmosRepository;
import com.ust.employee.model.Employee;

import reactor.core.publisher.Flux;
/**
 *  IEmployeeRepo a repository contains methods defined 
 * @author sanga
 *
 */
@Repository
public interface IEmployeeRepo extends  ReactiveCosmosRepository<Employee, Integer> {


   public  Flux<Employee> getEmpByName( String name);

    public void deleteById(String id);
 


 



}
