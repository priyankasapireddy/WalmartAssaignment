/**
 * Class: EmployeeController
 * 
 * Description: Controller class with autowiring service class for mapping 
 * 
 * date:10/12/2020
 */
package com.ust.employee.controller;

import static com.ust.employee.costant.ReportServiceConstant.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.employee.model.Employee;
import com.ust.employee.service.EmployeeService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * EmpController controller class by autowiring EmployeeService
 * 
 */

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	/**
	 * by get mapping annotation we can access getEmployeeList method internally
	 * 
	 * @return Flux<Employee>
	 **/
	@GetMapping(value = URL_MAPPING_GET_ALLEMPLOYEES)
	public Flux<Employee> getEmployeeList() {
		Flux<Employee> empList = service.getEmployeeList();
		return empList;
	}

	/**
	 * by @PostMapping we can add aemployee
	 * 
	 * @param employee
	 * @return Employee
	 */
	@PostMapping(value = URL_MAPPING_POST_ADDEMPLOYEE)
	public Employee saveEmployee(@RequestBody Employee employee) {
		Employee newEmployee = service.saveEmployee(employee);
		return newEmployee;
	}

	/**
	 * by @GetMapping annotation we can get employee by name
	 * 
	 * @param name
	 * @return Flux<Employee>
	 */
	@GetMapping(value = URL_MAPPING_GET_EMPLOYEEBYNAME)
	public Flux<Employee> getEmployeeByName(@PathVariable("name") String name) {
		Flux<Employee> empList = service.getEmployeeByName(name);
		return empList;
	}

	/**
	 * by updateEmployee method we can update the employee details
	 * 
	 * @param employeeId
	 * @param employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEEMPLOYEE, method = RequestMethod.PUT)
	public void updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {

		service.updateEmployee(employee);
	}

	/**
	 * by updateEmployeeBonous method we can update the employee bonous by their
	 * employeeId
	 * 
	 * @param employeeId
	 * @param employee
	 */
	@RequestMapping(value = URL_MAPPING_PUT_UPDATEBONOUS, method = RequestMethod.PUT)
	public void updateEmployeeBonous(@PathVariable int employeeId, @RequestBody Employee employee) {

		service.updateEmployeeBonous(employee);
	}

	/**
	 * by method assFreshers we can add list of freshers to employeeList
	 * 
	 * @param employee
	 * @return Flux<Employee>
	 */

	@PostMapping(value = URL_MAPPING_POST_ADDFRESHERS)

	public Flux<Employee> addFreshers(@RequestBody List<Employee> employee) {

		Flux<Employee> empList = service.addFreshers(employee);

		return empList;

	}

	/**
	 * deleteEmployee method to delete employee by id
	 * 
	 * @param id
	 * 
	 */
	@RequestMapping(value = URL_MAPPING_DELETE_DELETEEMPLOYEE, method = RequestMethod.DELETE)
	public String deleteEmployeeByid(@PathVariable String id) {
		return service.deleteEmployeeById(id);
	}

}
